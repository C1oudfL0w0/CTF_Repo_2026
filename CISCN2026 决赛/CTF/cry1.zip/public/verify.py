#!/usr/bin/env python3
import hashlib
import json
import sys
from pathlib import Path

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def aes_cbc_decrypt(key, iv, ct):
    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    padded = decryptor.update(ct) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


def main():
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} <private-key-hex>")
        raise SystemExit(1)

    chall = json.loads(Path("chall.json").read_text())
    d = int(sys.argv[1], 16)
    key = hashlib.sha256(d.to_bytes(32, "big")).digest()
    iv = bytes.fromhex(chall["cipher"]["iv"])
    ct = bytes.fromhex(chall["cipher"]["ciphertext"])

    try:
        flag = aes_cbc_decrypt(key, iv, ct)
    except ValueError:
        print("wrong key")
        raise SystemExit(1)

    print(flag.decode())


if __name__ == "__main__":
    main()
