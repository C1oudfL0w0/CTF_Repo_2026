#!/usr/bin/env python3
import cgi
import hashlib
import hmac
import html
import io
import json
import os
import queue
import re
import secrets
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


APP_HOST = os.environ.get("ARCHIVEHUB_HOST", "0.0.0.0")
APP_PORT = int(os.environ.get("ARCHIVEHUB_PORT", "8000"))
INTERNAL_HOST = "127.0.0.1"
INTERNAL_PORT = int(os.environ.get("ARCHIVEHUB_INTERNAL_PORT", "9001"))
DATA_DIR = os.environ.get("ARCHIVEHUB_DATA", "/tmp/archivehub")
DB_PATH = os.path.join(DATA_DIR, "archivehub.sqlite3")
THEME_DIR = os.path.join(DATA_DIR, "themes")
ADMIN_BOT_TOKEN = os.environ.get("ARCHIVEHUB_BOT_TOKEN") or secrets.token_urlsafe(24)
SESSION_TTL = 60 * 60 * 8
MAX_ZIP_SIZE = 256 * 1024
MAX_MARKDOWN_SIZE = 64 * 1024

DB_LOCK = threading.Lock()
REPORT_QUEUE = queue.Queue()


def now() -> int:
    return int(time.time())


def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def password_hash(password: str, salt: str | None = None) -> str:
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120000)
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, digest = stored.split("$", 1)
    except ValueError:
        return False
    return hmac.compare_digest(password_hash(password, salt), stored)


def init_db():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(THEME_DIR, exist_ok=True)
    with open(os.path.join(THEME_DIR, "plain.tpl"), "w", encoding="utf-8") as fp:
        fp.write("ArchiveHub preview theme: {{ title }}\n")

    with DB_LOCK, db_connect() as conn:
        conn.executescript(
            """
            create table if not exists users (
                id integer primary key autoincrement,
                username text unique not null,
                password_hash text not null,
                role text not null default 'user',
                created_at integer not null
            );
            create table if not exists sessions (
                sid text primary key,
                user_id integer not null,
                expires_at integer not null
            );
            create table if not exists documents (
                id integer primary key autoincrement,
                owner_id integer not null,
                title text not null,
                main_file text not null,
                content text not null,
                created_at integer not null
            );
            create table if not exists notes (
                id integer primary key autoincrement,
                document_id integer not null,
                author_id integer not null,
                body text not null,
                created_at integer not null
            );
            create table if not exists reports (
                id integer primary key autoincrement,
                document_id integer not null,
                reporter_id integer not null,
                status text not null,
                created_at integer not null
            );
            create table if not exists audit_log (
                id integer primary key autoincrement,
                action text not null,
                detail text not null,
                created_at integer not null
            );
            """
        )
        admin = conn.execute("select id from users where username = ?", ("admin",)).fetchone()
        if admin is None:
            conn.execute(
                "insert into users(username, password_hash, role, created_at) values(?, ?, ?, ?)",
                ("admin", password_hash(secrets.token_urlsafe(18)), "admin", now()),
            )
        sample = conn.execute("select id from documents where title = ?", ("Welcome to ArchiveHub",)).fetchone()
        if sample is None:
            admin_id = conn.execute("select id from users where username = ?", ("admin",)).fetchone()["id"]
            conn.execute(
                """
                insert into documents(owner_id, title, main_file, content, created_at)
                values(?, ?, ?, ?, ?)
                """,
                (
                    admin_id,
                    "Welcome to ArchiveHub",
                    "README.md",
                    "# Welcome\n\nUpload a zip archive with `manifest.json` and a Markdown file.\n",
                    now(),
                ),
            )


def audit(action: str, detail: str):
    with DB_LOCK, db_connect() as conn:
        conn.execute(
            "insert into audit_log(action, detail, created_at) values(?, ?, ?)",
            (action[:80], detail[:500], now()),
        )


def create_session(user_id: int) -> str:
    sid = secrets.token_urlsafe(32)
    with DB_LOCK, db_connect() as conn:
        conn.execute(
            "insert into sessions(sid, user_id, expires_at) values(?, ?, ?)",
            (sid, user_id, now() + SESSION_TTL),
        )
    return sid


def delete_session(sid: str):
    with DB_LOCK, db_connect() as conn:
        conn.execute("delete from sessions where sid = ?", (sid,))


def parse_cookie(header: str | None) -> dict[str, str]:
    if not header:
        return {}
    jar = cookies.SimpleCookie()
    try:
        jar.load(header)
    except cookies.CookieError:
        return {}
    return {key: morsel.value for key, morsel in jar.items()}


def session_cookie(sid: str) -> str:
    return f"sid={sid}; Path=/; HttpOnly; SameSite=Lax"


def clear_session_cookie() -> str:
    return "sid=deleted; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"


def escape(value) -> str:
    return html.escape(str(value), quote=True)


def weak_sanitize_raw_html(raw: str) -> str:
    """The intended bug: unquoted event attributes survive this sanitizer."""
    raw = re.sub(r"(?is)<\s*script\b.*?<\s*/\s*script\s*>", "", raw)
    raw = re.sub(r"(?is)<\s*/?\s*script\b[^>]*>", "", raw)
    raw = re.sub(r"(?i)\s+on[a-z0-9_:-]+\s*=\s*(\"[^\"]*\"|'[^']*')", "", raw)
    raw = re.sub(r"(?i)javascript\s*:", "", raw)
    return raw


def render_inline(text: str) -> str:
    out = escape(text)
    out = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", out)
    out = re.sub(r"`([^`]+)`", r"<code>\1</code>", out)
    return out


def render_markdown(markdown: str) -> str:
    html_parts: list[str] = []
    in_code = False
    code_lines: list[str] = []
    for raw_line in markdown.replace("\r\n", "\n").split("\n"):
        line = raw_line.rstrip("\n")
        if line.strip().startswith("```"):
            if in_code:
                html_parts.append("<pre><code>" + escape("\n".join(code_lines)) + "</code></pre>")
                code_lines = []
                in_code = False
            else:
                in_code = True
            continue
        if in_code:
            code_lines.append(line)
            continue

        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("# "):
            html_parts.append(f"<h1>{render_inline(stripped[2:])}</h1>")
        elif stripped.startswith("## "):
            html_parts.append(f"<h2>{render_inline(stripped[3:])}</h2>")
        elif stripped.startswith("<"):
            html_parts.append(weak_sanitize_raw_html(stripped))
        else:
            html_parts.append(f"<p>{render_inline(stripped)}</p>")
    if in_code:
        html_parts.append("<pre><code>" + escape("\n".join(code_lines)) + "</code></pre>")
    return "\n".join(html_parts)


def read_request_body(handler: BaseHTTPRequestHandler, limit: int = 1024 * 1024) -> bytes:
    length = int(handler.headers.get("Content-Length", "0") or "0")
    if length > limit:
        raise ValueError("request body is too large")
    return handler.rfile.read(length)


class MainHandler(BaseHTTPRequestHandler):
    server_version = "ArchiveHub/1.0"

    def log_message(self, fmt, *args):
        print("[web]", fmt % args, flush=True)

    def current_user(self):
        sid = parse_cookie(self.headers.get("Cookie")).get("sid")
        if not sid:
            return None
        with db_connect() as conn:
            row = conn.execute(
                """
                select users.* from sessions
                join users on users.id = sessions.user_id
                where sessions.sid = ? and sessions.expires_at > ?
                """,
                (sid, now()),
            ).fetchone()
        return row

    def send_bytes(self, body: bytes, content_type: str, status: int = 200, headers: list[tuple[str, str]] | None = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        if headers:
            for key, value in headers:
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, text: str, status: int = 200, headers: list[tuple[str, str]] | None = None):
        self.send_bytes(text.encode("utf-8"), "text/plain; charset=utf-8", status, headers)

    def send_html(self, title: str, body: str, status: int = 200, headers: list[tuple[str, str]] | None = None):
        user = self.current_user()
        nav = '<a href="/">ArchiveHub</a>'
        if user:
            nav += f'<span>signed in as {escape(user["username"])}</span><a href="/upload">Upload</a><a href="/logout">Logout</a>'
        else:
            nav += '<a href="/login">Login</a><a href="/register">Register</a>'
        page = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)} - ArchiveHub</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  <nav>{nav}</nav>
  <main>
    {body}
  </main>
</body>
</html>
"""
        self.send_bytes(page.encode("utf-8"), "text/html; charset=utf-8", status, headers)

    def redirect(self, location: str, headers: list[tuple[str, str]] | None = None):
        extra = [("Location", location)]
        if headers:
            extra.extend(headers)
        self.send_bytes(b"", "text/plain; charset=utf-8", 302, extra)

    def error_page(self, message: str, status: int = 400):
        self.send_html("Error", f"<section class=\"panel\"><h1>Error</h1><p>{escape(message)}</p></section>", status)

    def require_user(self):
        user = self.current_user()
        if user is None:
            self.redirect("/login")
            return None
        return user

    def require_admin(self):
        user = self.current_user()
        if user is None or user["role"] != "admin":
            self.error_page("admin only", 403)
            return None
        return user

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/static/style.css":
            css_path = os.path.join(os.path.dirname(__file__), "static", "style.css")
            with open(css_path, "rb") as fp:
                self.send_bytes(fp.read(), "text/css; charset=utf-8")
            return
        if path == "/healthz":
            self.send_text("ok\n")
            return
        if path == "/":
            self.home()
            return
        if path == "/register":
            self.auth_form("Register", "/register")
            return
        if path == "/login":
            self.auth_form("Login", "/login")
            return
        if path == "/logout":
            sid = parse_cookie(self.headers.get("Cookie")).get("sid")
            if sid:
                delete_session(sid)
            self.redirect("/", [("Set-Cookie", clear_session_cookie())])
            return
        if path == "/upload":
            self.upload_form()
            return
        if path.startswith("/documents/"):
            parts = path.strip("/").split("/")
            if len(parts) == 2 and parts[1].isdigit():
                self.document_page(int(parts[1]))
                return
        if path.startswith("/admin/review/"):
            parts = path.strip("/").split("/")
            if len(parts) == 3 and parts[2].isdigit():
                self.admin_review(int(parts[2]), query)
                return
        if path == "/admin/fetch":
            self.admin_fetch(query)
            return
        self.error_page("not found", 404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/register":
            self.register()
            return
        if path == "/login":
            self.login()
            return
        if path == "/upload":
            self.upload()
            return
        if path.startswith("/documents/") and path.endswith("/report"):
            parts = path.strip("/").split("/")
            if len(parts) == 3 and parts[1].isdigit():
                self.report_document(int(parts[1]))
                return
        if path.startswith("/api/documents/") and path.endswith("/notes"):
            parts = path.strip("/").split("/")
            if len(parts) == 4 and parts[2].isdigit():
                self.write_note(int(parts[2]))
                return
        self.error_page("not found", 404)

    def auth_form(self, title: str, action: str, message: str = ""):
        msg = f'<p class="flash">{escape(message)}</p>' if message else ""
        body = f"""
<section class="panel narrow">
  <h1>{escape(title)}</h1>
  {msg}
  <form method="post" action="{escape(action)}">
    <label>Username <input name="username" autocomplete="username" required></label>
    <label>Password <input name="password" type="password" autocomplete="current-password" required></label>
    <button type="submit">{escape(title)}</button>
  </form>
</section>
"""
        self.send_html(title, body)

    def parse_form(self) -> dict[str, str]:
        body = read_request_body(self)
        parsed = urllib.parse.parse_qs(body.decode("utf-8", "replace"), keep_blank_values=True)
        return {key: values[-1] for key, values in parsed.items()}

    def register(self):
        form = self.parse_form()
        username = form.get("username", "").strip()
        password = form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", username):
            self.auth_form("Register", "/register", "username must be 3-24 letters, digits, or underscores")
            return
        if len(password) < 6:
            self.auth_form("Register", "/register", "password must contain at least 6 characters")
            return
        try:
            with DB_LOCK, db_connect() as conn:
                cur = conn.execute(
                    "insert into users(username, password_hash, role, created_at) values(?, ?, 'user', ?)",
                    (username, password_hash(password), now()),
                )
                user_id = cur.lastrowid
        except sqlite3.IntegrityError:
            self.auth_form("Register", "/register", "username already exists")
            return
        sid = create_session(user_id)
        self.redirect("/", [("Set-Cookie", session_cookie(sid))])

    def login(self):
        form = self.parse_form()
        username = form.get("username", "")
        password = form.get("password", "")
        with db_connect() as conn:
            user = conn.execute("select * from users where username = ?", (username,)).fetchone()
        if user is None or not verify_password(password, user["password_hash"]):
            self.auth_form("Login", "/login", "invalid username or password")
            return
        sid = create_session(user["id"])
        self.redirect("/", [("Set-Cookie", session_cookie(sid))])

    def home(self):
        user = self.current_user()
        with db_connect() as conn:
            if user:
                docs = conn.execute(
                    """
                    select documents.*, users.username as owner_name from documents
                    join users on users.id = documents.owner_id
                    where documents.owner_id = ? or ? = 'admin'
                    order by documents.id desc
                    """,
                    (user["id"], user["role"]),
                ).fetchall()
            else:
                docs = conn.execute(
                    """
                    select documents.*, users.username as owner_name from documents
                    join users on users.id = documents.owner_id
                    where documents.title = 'Welcome to ArchiveHub'
                    """
                ).fetchall()
        rows = []
        for doc in docs:
            rows.append(
                f"""
<article class="doc-row">
  <a href="/documents/{doc["id"]}">{escape(doc["title"])}</a>
  <span>{escape(doc["main_file"])} by {escape(doc["owner_name"])}</span>
</article>
"""
            )
        intro = """
<section class="hero">
  <h1>ArchiveHub</h1>
  <p>Offline archive review system for campus security materials.</p>
</section>
"""
        body = intro + '<section class="panel"><h2>Documents</h2>' + "\n".join(rows or ["<p>No documents yet.</p>"]) + "</section>"
        self.send_html("Home", body)

    def upload_form(self):
        if self.require_user() is None:
            return
        body = """
<section class="panel">
  <h1>Upload Archive</h1>
  <p class="muted">Upload a zip with manifest.json and one Markdown file.</p>
  <pre class="sample">{"title":"Course Notes","main":"README.md"}</pre>
  <form method="post" action="/upload" enctype="multipart/form-data">
    <label>Archive title <input name="title" placeholder="optional"></label>
    <label>Zip file <input name="archive" type="file" accept=".zip" required></label>
    <button type="submit">Upload</button>
  </form>
</section>
"""
        self.send_html("Upload", body)

    def upload(self):
        user = self.require_user()
        if user is None:
            return
        ctype = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in ctype:
            self.error_page("multipart form expected")
            return
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={
                "REQUEST_METHOD": "POST",
                "CONTENT_TYPE": ctype,
                "CONTENT_LENGTH": self.headers.get("Content-Length", "0"),
            },
        )
        if "archive" not in form:
            self.error_page("missing archive")
            return
        file_item = form["archive"]
        title_hint = ""
        if "title" in form:
            title_hint = form["title"].value.strip()
        data = file_item.file.read(MAX_ZIP_SIZE + 1)
        if len(data) > MAX_ZIP_SIZE:
            self.error_page("archive is too large")
            return
        try:
            title, main_file, content = parse_archive(data, title_hint)
        except ValueError as exc:
            self.error_page(str(exc))
            return
        with DB_LOCK, db_connect() as conn:
            cur = conn.execute(
                """
                insert into documents(owner_id, title, main_file, content, created_at)
                values(?, ?, ?, ?, ?)
                """,
                (user["id"], title, main_file, content, now()),
            )
            doc_id = cur.lastrowid
        self.redirect(f"/documents/{doc_id}")

    def load_document(self, doc_id: int):
        with db_connect() as conn:
            return conn.execute(
                """
                select documents.*, users.username as owner_name from documents
                join users on users.id = documents.owner_id
                where documents.id = ?
                """,
                (doc_id,),
            ).fetchone()

    def can_view(self, user, doc) -> bool:
        if doc is None:
            return False
        if doc["title"] == "Welcome to ArchiveHub":
            return True
        if user is None:
            return False
        return user["role"] == "admin" or doc["owner_id"] == user["id"]

    def document_page(self, doc_id: int):
        user = self.current_user()
        doc = self.load_document(doc_id)
        if not self.can_view(user, doc):
            self.error_page("document not found", 404)
            return
        with db_connect() as conn:
            notes = conn.execute(
                """
                select notes.*, users.username as author_name from notes
                join users on users.id = notes.author_id
                where notes.document_id = ?
                order by notes.id asc
                """,
                (doc_id,),
            ).fetchall()
        note_html = "\n".join(
            f'<div class="note"><b>{escape(note["author_name"])}</b><pre>{escape(note["body"])}</pre></div>' for note in notes
        )
        report_form = ""
        if user and doc["owner_id"] == user["id"]:
            report_form = f"""
<form method="post" action="/documents/{doc_id}/report" class="inline">
  <button type="submit">Request admin review</button>
</form>
"""
        body = f"""
<section class="panel document">
  <div class="doc-head">
    <div>
      <h1>{escape(doc["title"])}</h1>
      <p class="muted">{escape(doc["main_file"])} by {escape(doc["owner_name"])}</p>
    </div>
    {report_form}
  </div>
  <div class="rendered">{render_markdown(doc["content"])}</div>
</section>
<section class="panel">
  <h2>Review Notes</h2>
  {note_html or '<p class="muted">No notes yet.</p>'}
</section>
"""
        self.send_html(doc["title"], body)

    def report_document(self, doc_id: int):
        user = self.require_user()
        if user is None:
            return
        doc = self.load_document(doc_id)
        if doc is None or doc["owner_id"] != user["id"]:
            self.error_page("document not found", 404)
            return
        with DB_LOCK, db_connect() as conn:
            conn.execute(
                "insert into reports(document_id, reporter_id, status, created_at) values(?, ?, ?, ?)",
                (doc_id, user["id"], "queued", now()),
            )
        REPORT_QUEUE.put(doc_id)
        self.send_html(
            "Review queued",
            f"""
<section class="panel">
  <h1>Review queued</h1>
  <p>The admin bot will review document #{doc_id} shortly.</p>
  <p><a href="/documents/{doc_id}">Back to document</a></p>
</section>
""",
        )

    def admin_review(self, doc_id: int, query: dict[str, list[str]]):
        headers = []
        token = query.get("bot_token", [""])[0]
        user = None
        if hmac.compare_digest(token, ADMIN_BOT_TOKEN):
            with db_connect() as conn:
                user = conn.execute("select * from users where username = 'admin'").fetchone()
            sid = create_session(user["id"])
            headers.append(("Set-Cookie", session_cookie(sid)))

        if user is None:
            user = self.current_user()
        if user is None or user["role"] != "admin":
            self.error_page("admin only", 403)
            return
        doc = self.load_document(doc_id)
        if doc is None:
            self.error_page("document not found", 404)
            return
        body = f"""
<section class="panel document">
  <div class="doc-head">
    <div>
      <h1>Admin Review</h1>
      <p class="muted">Document #{doc_id}: {escape(doc["title"])}</p>
    </div>
  </div>
  <div class="rendered">{render_markdown(doc["content"])}</div>
</section>
"""
        self.send_html("Admin Review", body, headers=headers)

    def admin_fetch(self, query: dict[str, list[str]]):
        if self.require_admin() is None:
            return
        url = query.get("url", [""])[0]
        if len(url) > 1200:
            self.send_text("url too long", 400)
            return
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if parsed.scheme not in ("http", "https"):
            self.send_text("blocked: scheme", 400)
            return
        if host in {"127.0.0.1", "localhost", "0.0.0.0", "::1"}:
            self.send_text("blocked: loopback host", 400)
            return
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "ArchiveHub-MetadataBot/1.0"})
            with urllib.request.urlopen(req, timeout=3) as response:
                body = response.read(8192)
                ctype = response.headers.get("Content-Type", "text/plain")
        except Exception as exc:
            audit("admin_fetch_error", f"{url} => {exc}")
            self.send_text(f"fetch failed: {exc}", 502)
            return
        audit("admin_fetch", url)
        safe_ctype = "text/plain; charset=utf-8"
        if ctype.startswith("application/json"):
            safe_ctype = "application/json; charset=utf-8"
        self.send_bytes(body, safe_ctype)

    def write_note(self, doc_id: int):
        user = self.current_user()
        if user is None:
            self.send_text("login required", 403)
            return
        doc = self.load_document(doc_id)
        if doc is None or (user["role"] != "admin" and doc["owner_id"] != user["id"]):
            self.send_text("document not found", 404)
            return
        raw = read_request_body(self, 16384)
        ctype = self.headers.get("Content-Type", "")
        if "application/x-www-form-urlencoded" in ctype:
            parsed = urllib.parse.parse_qs(raw.decode("utf-8", "replace"), keep_blank_values=True)
            body = parsed.get("body", [""])[-1]
        else:
            body = raw.decode("utf-8", "replace")
        body = body.strip()[:8000]
        if not body:
            self.send_text("empty note", 400)
            return
        with DB_LOCK, db_connect() as conn:
            conn.execute(
                "insert into notes(document_id, author_id, body, created_at) values(?, ?, ?, ?)",
                (doc_id, user["id"], body, now()),
            )
        self.send_text("ok\n")


def parse_archive(data: bytes, title_hint: str) -> tuple[str, str, str]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise ValueError("invalid zip archive") from exc
    with zf:
        infos = zf.infolist()
        if not infos:
            raise ValueError("empty archive")
        if sum(info.file_size for info in infos) > MAX_ZIP_SIZE * 3:
            raise ValueError("uncompressed archive is too large")
        names = {info.filename for info in infos if not info.is_dir()}
        manifest = {}
        if "manifest.json" in names:
            try:
                manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
            except Exception as exc:
                raise ValueError("manifest.json is invalid") from exc
        main_file = str(manifest.get("main") or "README.md")
        if main_file not in names:
            markdowns = sorted(name for name in names if name.lower().endswith((".md", ".markdown")))
            if not markdowns:
                raise ValueError("archive must contain a Markdown file")
            main_file = markdowns[0]
        if not main_file.lower().endswith((".md", ".markdown")):
            raise ValueError("main file must be Markdown")
        content = zf.read(main_file)
        if len(content) > MAX_MARKDOWN_SIZE:
            raise ValueError("Markdown file is too large")
        title = str(manifest.get("title") or title_hint or os.path.basename(main_file)).strip()
        title = re.sub(r"\s+", " ", title)[:80] or "Untitled Archive"
        return title, main_file, content.decode("utf-8", "replace")


class TemplateHelper:
    def c(self, *codes):
        return "".join(chr(int(code)) for code in codes)

    def a(self, obj, name):
        return getattr(obj, name)


class ThemeConfig:
    title = "ArchiveHub Internal Preview"

    def public(self, name):
        safe = os.path.normpath("/" + name).lstrip("/")
        path = os.path.join(THEME_DIR, safe)
        if not os.path.realpath(path).startswith(os.path.realpath(THEME_DIR) + os.sep):
            return "blocked"
        with open(path, "r", encoding="utf-8", errors="replace") as fp:
            return fp.read(1000)

    def _load(self, path):
        with open(path, "r", encoding="utf-8", errors="replace") as fp:
            return fp.read(4000)


class InternalHandler(BaseHTTPRequestHandler):
    server_version = "ArchiveHubInternal/1.0"

    def log_message(self, fmt, *args):
        print("[internal]", fmt % args, flush=True)

    def send_text(self, text: str, status: int = 200):
        body = text.encode("utf-8", "replace")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/status":
            self.send_text("internal renderer online\n")
            return
        if parsed.path == "/render":
            tpl = query.get("tpl", ["ArchiveHub internal preview"])[0]
            self.send_text(render_internal_template(tpl))
            return
        self.send_text("not found\n", 404)


def render_internal_template(template: str) -> str:
    if len(template) > 1000:
        return "template too long"

    def replace(match):
        expr = match.group(1).strip()
        lowered = expr.lower()
        blocked = ["_", "flag", "open", "import", "os", "subprocess", "builtins", "globals", "eval", "exec"]
        if any(word in lowered for word in blocked):
            return "[blocked]"
        try:
            return str(
                eval(
                    expr,
                    {"__builtins__": {}},
                    {"cfg": ThemeConfig(), "h": TemplateHelper(), "title": ThemeConfig.title},
                )
            )
        except Exception as exc:
            return f"[error: {exc}]"

    return re.sub(r"\{\{(.*?)\}\}", replace, template, flags=re.S)


def find_chromium() -> str | None:
    for name in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
        path = shutil.which(name)
        if path:
            return path
    return None


def visit_as_admin(doc_id: int):
    chrome = find_chromium()
    if not chrome:
        audit("bot_missing", "chromium executable not found")
        print("[bot] chromium not found; report cannot be reviewed", flush=True)
        return
    url = f"http://127.0.0.1:{APP_PORT}/admin/review/{doc_id}?bot_token={urllib.parse.quote(ADMIN_BOT_TOKEN)}"
    profile = tempfile.mkdtemp(prefix="archivehub-bot-")
    base_cmd = [
        chrome,
        "--headless=new",
        "--no-sandbox",
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-background-networking",
        "--disable-sync",
        "--no-first-run",
        f"--user-data-dir={profile}",
        "--virtual-time-budget=6000",
        url,
    ]
    try:
        result = subprocess.run(base_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=12)
        if result.returncode != 0:
            fallback = base_cmd.copy()
            fallback[1] = "--headless"
            subprocess.run(fallback, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=12)
        audit("bot_visit", f"document={doc_id}")
    except subprocess.TimeoutExpired:
        audit("bot_timeout", f"document={doc_id}")
    finally:
        shutil.rmtree(profile, ignore_errors=True)


def bot_worker():
    while True:
        doc_id = REPORT_QUEUE.get()
        try:
            time.sleep(1.0)
            print(f"[bot] reviewing document {doc_id}", flush=True)
            visit_as_admin(doc_id)
            with DB_LOCK, db_connect() as conn:
                conn.execute("update reports set status = 'reviewed' where document_id = ?", (doc_id,))
        except Exception as exc:
            audit("bot_error", repr(exc))
        finally:
            REPORT_QUEUE.task_done()


def run():
    init_db()
    threading.Thread(target=bot_worker, daemon=True).start()
    internal = ThreadingHTTPServer((INTERNAL_HOST, INTERNAL_PORT), InternalHandler)
    threading.Thread(target=internal.serve_forever, daemon=True).start()
    print(f"[internal] listening on {INTERNAL_HOST}:{INTERNAL_PORT}", flush=True)
    print(f"[web] listening on {APP_HOST}:{APP_PORT}", flush=True)
    web = ThreadingHTTPServer((APP_HOST, APP_PORT), MainHandler)
    web.serve_forever()


if __name__ == "__main__":
    run()
