# TinyVaultChain Protocol

本题使用一个最小化的本地链协议。签名曲线为 secp256k1，签名算法为标准 ECDSA。

## 地址

公钥点为 `(x, y)`。地址计算方式：

```text
address = "0x" + last_20_bytes(hex(sha256(x || y)))
```

其中 `x` 和 `y` 都按 32 字节大端编码后拼接。本题不是以太坊主网协议，地址哈希不是 Keccak。

## 未签名交易

未签名交易必须包含以下字段：

```json
{
  "chain_id": 26001,
  "from": "0x...",
  "to": "0x...",
  "nonce": 0,
  "value": 0,
  "method": "method_name",
  "params": {}
}
```

签名消息为未签名交易的规范 JSON：

```python
json.dumps(unsigned_tx, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
```

签名哈希：

```text
z = int(sha256(canonical_json(unsigned_tx)), 16)
```

## 签名

ECDSA 签名格式：

```json
{
  "r": "0x...",
  "s": "0x...",
  "v": 0
}
```

`r` 和 `s` 是 32 字节十六进制整数。`v` 是签名临时点 `R = kG` 的 `y` 坐标奇偶位，取值为 `0` 或 `1`。

## Vault 提款交易

提款交易需要满足：

```json
{
  "chain_id": 26001,
  "from": "<recovery signer address>",
  "to": "<Vault address>",
  "nonce": 2,
  "value": 0,
  "method": "withdraw",
  "params": {
    "receiver": "0x...",
    "amount": 1337
  }
}
```

最终提交给 RPC 的对象只需要包含 `unsigned` 和 `signature` 两个字段。
