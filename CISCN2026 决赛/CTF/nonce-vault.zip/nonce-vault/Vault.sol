// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract Vault {
    address public immutable recoverySigner;
    uint256 public constant VAULT_BALANCE = 1337;
    bool public drained;

    event Withdraw(address indexed receiver, uint256 amount);

    constructor(address _recoverySigner) {
        recoverySigner = _recoverySigner;
    }

    modifier onlyRecoverySigner() {
        require(msg.sender == recoverySigner, "only recovery signer");
        _;
    }

    function set_daily_limit(uint256) external onlyRecoverySigner {
        // Historical maintenance method.
    }

    function sweep_dust(address, uint256) external onlyRecoverySigner {
        // Historical maintenance method.
    }

    function withdraw(address receiver, uint256 amount) external onlyRecoverySigner {
        require(!drained, "already drained");
        require(amount == VAULT_BALANCE, "must drain the vault");
        drained = true;
        emit Withdraw(receiver, amount);
    }
}
