# OriginVault 选手附件

目标服务是一个合约插件审核平台。访问 Web 后可通过 `/api/config` 获取当前实例的 Vault 地址、链 ID、RPC 路径和 ABI。

已知信息：

- JSON-RPC 路径：`/rpc`
- 领取测试 ETH：`POST /api/faucet`
- 提交插件审核：`POST /api/submit_plugin`
- 插件需要实现：`onReview(address vault)`
- 获取 flag 需要成为当前 Vault admin，并用该地址对 `/api/nonce` 返回的消息签名后提交 `/api/flag`

附件内容：

- `contracts/Vault.sol`：目标合约源码
- `contracts/IPlugin.sol`：插件接口
- `abi/Vault.abi.json`：Vault ABI
- `修补环境说明.md`：AWDP 修补脚本运行环境说明
- `update.sh`：选手上传到平台执行的修补脚本模板

