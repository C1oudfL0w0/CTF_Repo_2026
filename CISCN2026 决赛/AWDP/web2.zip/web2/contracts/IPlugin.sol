// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IPlugin {
    function onReview(address vault) external;
}
