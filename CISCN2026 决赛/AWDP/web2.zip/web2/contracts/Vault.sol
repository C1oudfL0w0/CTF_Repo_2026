// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IPlugin {
    function onReview(address vault) external;
}

contract Vault {
    address public admin;
    uint256 public riskLimit;
    uint256 public reviewCount;
    mapping(address => bool) public approvedPlugins;

    event AdminChanged(address indexed oldAdmin, address indexed newAdmin);
    event PluginReviewed(address indexed plugin);
    event RiskLimitChanged(uint256 oldLimit, uint256 newLimit);
    event EmergencyWithdraw(address indexed to, uint256 amount);

    constructor() payable {
        admin = msg.sender;
        riskLimit = 10;
    }

    receive() external payable {}

    modifier onlyAdmin() {
        require(tx.origin == admin, "not admin");
        _;
    }

    function reviewPlugin(address plugin) external onlyAdmin {
        require(plugin.code.length > 0, "plugin required");
        IPlugin(plugin).onReview(address(this));
        approvedPlugins[plugin] = true;
        reviewCount += 1;
        emit PluginReviewed(plugin);
    }

    function transferAdmin(address newAdmin) external onlyAdmin {
        require(newAdmin != address(0), "bad admin");
        address oldAdmin = admin;
        admin = newAdmin;
        emit AdminChanged(oldAdmin, newAdmin);
    }

    function setRiskLimit(uint256 newLimit) external onlyAdmin {
        require(newLimit > 0 && newLimit <= 100, "bad limit");
        uint256 oldLimit = riskLimit;
        riskLimit = newLimit;
        emit RiskLimitChanged(oldLimit, newLimit);
    }

    function emergencyWithdraw(address payable to) external onlyAdmin {
        require(to != address(0), "bad receiver");
        uint256 amount = address(this).balance;
        to.transfer(amount);
        emit EmergencyWithdraw(to, amount);
    }
}
