#!/bin/sh
set -eu

TARGET_DIR=${TARGET_DIR:-/app}
VAULT_FILE="$TARGET_DIR/contracts/Vault.sol"
PID_FILE=/tmp/origin-vault.pid

if [ ! -f "$VAULT_FILE" ]; then
  echo "Vault source not found: $VAULT_FILE" >&2
  exit 1
fi

# TODO:
#   Write your patch here.
#   The service compiles and deploys contracts/Vault.sol when Node restarts.
#   Keep normal APIs working: /rpc, /api/faucet, /api/submit_plugin, /api/vault_state.
#
# Example structure:
#   1. Modify "$VAULT_FILE" or replace it with your patched Vault.sol.
#   2. Do not modify /flag.
#   3. Restart Node using the block below.

if [ -s "$PID_FILE" ]; then
  kill "$(cat "$PID_FILE")" >/dev/null 2>&1 || true
else
  echo "PID file not found, service may need manual restart" >&2
fi

echo "patch script finished"
