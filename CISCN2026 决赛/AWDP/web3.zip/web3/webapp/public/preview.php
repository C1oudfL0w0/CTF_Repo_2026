<?php

declare(strict_types=1);

require __DIR__ . '/_init.php';

use App\NoticeFragmentCollection;
use App\NoticePreviewInput;
use App\NoticePreviewRenderer;

$tpl = (string)($_POST['tpl'] ?? '');
if ($tpl === '') {
    http_response_code(400);
    exit('missing tpl');
}

$input = NoticePreviewInput::fromRequest($_POST);
$snippetItems = $_SESSION['snippets'] ?? [];
$fragments = NoticeFragmentCollection::fromRecords($snippetItems);
$error = null;
$rendered = '';

try {
    $rendered = (new NoticePreviewRenderer())->render($input, $fragments);
} catch (\Throwable $e) {
    http_response_code(400);
    error_log('[preview] ' . $e->getMessage());
    $error = '通知预览失败，请检查通知内容或联系空间管理员。';
}

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>通知预览 - NorthLine 通知编排中心</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="app-body">
  <div class="shell">
    <aside class="app-sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">NL</div>
        <div class="brand-text">
          <strong>NorthLine</strong>
          <span>通知编排中心</span>
        </div>
      </div>

      <nav class="nav-group">
        <a class="nav-item" href="/">工作台</a>
        <a class="nav-item" href="/draft.php">通知草稿</a>
        <a class="nav-item active" href="/draft.php">发布预览</a>
        <a class="nav-item" href="/upload.php">共享片段</a>
        <a class="nav-item" href="/records.php">发布记录</a>
      </nav>

      <div class="nav-caption">团队空间</div>
      <nav class="nav-group nav-group-secondary">
        <a class="nav-item" href="/records.php">成员与权限</a>
        <a class="nav-item" href="/records.php">操作日志</a>
      </nav>

      <div class="sidebar-footer">
        <p>当前空间：市场运营组</p>
        <p>版本：2026.08</p>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-header">
        <div class="breadcrumb-block">
          <p class="breadcrumb">通知编排中心 / 发布预览</p>
          <h1 class="page-title">通知预览</h1>
        </div>

        <label class="search-box" aria-label="搜索通知、模板或片段">
          <span>搜索通知、模板或片段</span>
          <input type="search" placeholder="搜索通知、模板或片段">
        </label>

        <div class="header-actions">
          <a class="help-link" href="#">帮助</a>
          <div class="user-card">
            <div class="user-avatar">林</div>
            <div>
              <strong>林默</strong>
              <p>运营管理员</p>
            </div>
          </div>
        </div>
      </header>

      <main class="page-content">
        <section class="panel hero-panel">
          <div>
            <p class="eyebrow">发布预览</p>
            <h2>查看通知在不同渠道中的展示效果</h2>
            <p class="section-desc">生成当前通知在目标渠道中的展示效果，确认内容无误后提交审核。</p>
          </div>
          <div class="button-row">
            <a class="btn btn-secondary" href="/draft.php">返回编辑</a>
            <a class="btn btn-secondary" href="/draft.php">保存草稿</a>
            <a class="btn btn-primary" href="/records.php">提交审核</a>
          </div>
        </section>

        <section class="preview-page-grid">
          <section class="panel preview-panel">
            <div class="section-head section-head--preview">
              <div>
                <h2>通知预览</h2>
                <p class="section-desc">生成当前通知在目标渠道中的展示效果。</p>
              </div>
              <div class="preview-meta-tags">
                <span class="info-badge"><?= h($input->category()) ?></span>
                <span class="info-badge"><?= h($input->plannedWindow()) ?></span>
              </div>
            </div>

            <div class="preview-summary-card">
              <div>
                <span class="summary-label">通知标题</span>
                <strong><?= h($input->subject()) ?></strong>
              </div>
              <div>
                <span class="summary-label">通知分类</span>
                <strong><?= h($input->category()) ?></strong>
              </div>
              <div>
                <span class="summary-label">更新时间</span>
                <strong><?= h($input->plannedWindow()) ?></strong>
              </div>
            </div>

            <?php if ($error !== null): ?>
              <section class="message-card message-card--error">
                <strong>通知内容暂时无法展示，请稍后重试。</strong>
                <p><?= h($error) ?></p>
              </section>
            <?php else: ?>
              <section class="render-stage preview-render-stage">
                <?= $rendered ?>
              </section>
            <?php endif; ?>
          </section>

          <aside class="stacked-panels">
            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>发布设置</h2>
                  <p class="section-desc">确认目标渠道与范围信息。</p>
                </div>
              </div>
              <div class="channel-list">
                <label class="check-row"><input type="checkbox" checked disabled> <span>企业微信</span></label>
                <label class="check-row"><input type="checkbox" checked disabled> <span>邮件</span></label>
                <label class="check-row"><input type="checkbox" checked disabled> <span>站内信</span></label>
                <label class="check-row"><input type="checkbox" disabled> <span>短信</span></label>
              </div>
              <div class="coverage-box">
                <strong>预计覆盖 12,480 名成员</strong>
                <p>所属空间：市场运营组</p>
                <p>内容状态：草稿</p>
                <p>最近编辑：<?= h($input->operatorName()) ?></p>
              </div>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>通知信息</h2>
                  <p class="section-desc">当前请求中附带的基础字段。</p>
                </div>
              </div>
              <dl class="meta-list">
                <div><dt>目标对象</dt><dd><?= h($input->audience()) ?></dd></div>
                <div><dt>通知等级</dt><dd><?= h($input->severity()) ?></dd></div>
                <div><dt>联系邮箱</dt><dd><?= h($input->operatorEmail()) ?></dd></div>
                <div><dt>共享片段</dt><dd><?= h((string)count($fragments)) ?> 个</dd></div>
              </dl>
            </section>
          </aside>
        </section>
      </main>
    </div>
  </div>
</body>
</html>
