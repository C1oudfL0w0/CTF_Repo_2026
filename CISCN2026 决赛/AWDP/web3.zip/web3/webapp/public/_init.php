<?php

declare(strict_types=1);

session_start();

$root = __DIR__;
$autoload = $root . '/vendor/autoload.php';
if (!is_file($autoload)) {
    $parent = dirname(__DIR__);
    if (is_file($parent . '/vendor/autoload.php')) {
        $root = $parent;
        $autoload = $parent . '/vendor/autoload.php';
    } else {
        $root = '/opt/app';
        $autoload = $root . '/vendor/autoload.php';
    }
}

require $autoload;

spl_autoload_register(static function (string $class) use ($root): void {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $path = $root . '/src/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require $path;
    }
});

if (!defined('APP_ROOT')) {
    define('APP_ROOT', $root);
}
if (!defined('APP_UPLOAD_DIR')) {
    define('APP_UPLOAD_DIR', '/var/www/uploads');
}

if (!is_dir(APP_UPLOAD_DIR)) {
    @mkdir(APP_UPLOAD_DIR, 0775, true);
}
