<?php

declare(strict_types=1);

require __DIR__ . '/_init.php';

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$stats = [
    ['label' => '待处理草稿', 'value' => '12', 'meta' => '较上周 +8%'],
    ['label' => '本周已发布', 'value' => '38', 'meta' => '本周新增'],
    ['label' => '共享片段', 'value' => '86', 'meta' => '可复用内容'],
    ['label' => '待审核', 'value' => '4', 'meta' => '需要处理'],
];

$recentNotices = [
    ['title' => '春节会员权益调整通知', 'status' => '草稿', 'time' => '5分钟前'],
    ['title' => '华东区域服务时间变更', 'status' => '待审核', 'time' => '1小时前'],
    ['title' => '积分商城维护公告', 'status' => '已发布', 'time' => '昨天'],
    ['title' => '客户服务渠道升级说明', 'status' => '草稿', 'time' => '2天前'],
];

$quickActions = [
    ['title' => '新建通知', 'desc' => '进入草稿编辑页，填写标题、摘要与正文。', 'href' => '/draft.php'],
    ['title' => '从模板创建', 'desc' => '复用常用模板快速生成通知草稿。', 'href' => '/draft.php?template=rights'],
    ['title' => '导入共享片段', 'desc' => '上传团队常用文本片段，便于后续复用。', 'href' => '/upload.php'],
    ['title' => '发布记录', 'desc' => '查看已发布通知与审核流转记录。', 'href' => '/records.php'],
];

$activities = [
    '林默创建了《华东区域服务时间变更》',
    '陈璇发布了《积分商城维护公告》',
    '王启更新了共享片段「客户服务热线」',
    '林默保存了《春节会员权益调整通知》',
];

$alerts = [
    '本周还有 4 条通知待审核，建议优先处理活动类公告。',
    '共享片段库已累计 86 条，可优先复用常用客服口径。',
];
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NorthLine · 通知编排中心</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="app-body">
  <div class="shell">
    <aside class="app-sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">NL</div>
        <div class="brand-text">
          <strong>NorthLine</strong>
          <span>通知编排中心</span>
        </div>
      </div>

      <nav class="nav-group">
        <a class="nav-item active" href="/">工作台</a>
        <a class="nav-item" href="/draft.php">通知草稿</a>
        <a class="nav-item" href="/draft.php">发布预览</a>
        <a class="nav-item" href="/upload.php">共享片段</a>
        <a class="nav-item" href="/records.php">发布记录</a>
      </nav>

      <div class="nav-caption">团队空间</div>
      <nav class="nav-group nav-group-secondary">
        <a class="nav-item" href="/records.php">成员与权限</a>
        <a class="nav-item" href="/records.php">操作日志</a>
      </nav>

      <div class="sidebar-footer">
        <p>当前空间：市场运营组</p>
        <p>版本：2026.08</p>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-header">
        <div class="breadcrumb-block">
          <p class="breadcrumb">通知编排中心 / 工作台</p>
          <h1 class="page-title">NorthLine 通知编排中心</h1>
        </div>

        <label class="search-box" aria-label="搜索通知、模板或片段">
          <span>搜索通知、模板或片段</span>
          <input type="search" placeholder="搜索通知、模板或片段">
        </label>

        <div class="header-actions">
          <a class="help-link" href="#">帮助</a>
          <div class="user-card">
            <div class="user-avatar">林</div>
            <div>
              <strong>林默</strong>
              <p>运营管理员</p>
            </div>
          </div>
        </div>
      </header>

      <main class="page-content">
        <section class="panel hero-panel">
          <div>
            <p class="eyebrow">工作台概览</p>
            <h2>统一管理通知草稿、共享片段与发布记录</h2>
            <p class="section-desc">企业内部用于创建、编辑、预览、审核和发布运营通知的管理平台。支持复用共享片段、快速生成预览并进入审核流。</p>
          </div>
          <div class="button-row">
            <a class="btn btn-primary" href="/draft.php">新建通知</a>
            <a class="btn btn-secondary" href="/draft.php?template=rights">从模板创建</a>
            <a class="btn btn-secondary" href="/upload.php">导入共享片段</a>
          </div>
        </section>

        <section class="stat-grid">
          <?php foreach ($stats as $item): ?>
            <article class="panel stat-card">
              <span class="stat-label"><?= h($item['label']) ?></span>
              <strong><?= h($item['value']) ?></strong>
              <p><?= h($item['meta']) ?></p>
            </article>
          <?php endforeach; ?>
        </section>

        <section class="dashboard-grid">
          <section class="panel">
            <div class="section-head">
              <div>
                <h2>最近编辑的通知</h2>
                <p class="section-desc">最近 48 小时内更新的通知草稿与发布记录。</p>
              </div>
            </div>
            <div class="notice-list">
              <?php foreach ($recentNotices as $item): ?>
                <?php $statusClass = match ($item['status']) {
                    '草稿' => 'draft',
                    '待审核' => 'pending',
                    '已发布' => 'published',
                    '已归档' => 'archived',
                    default => 'draft',
                }; ?>
                <article class="notice-row">
                  <div>
                    <strong><?= h($item['title']) ?></strong>
                    <p><?= h($item['time']) ?></p>
                  </div>
                  <span class="status-tag status-tag--<?= h($statusClass) ?>"><?= h($item['status']) ?></span>
                </article>
              <?php endforeach; ?>
            </div>
          </section>

          <aside class="stacked-panels">
            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>快速开始</h2>
                  <p class="section-desc">常用入口已按业务分层整理。</p>
                </div>
              </div>
              <div class="action-list">
                <?php foreach ($quickActions as $action): ?>
                  <a class="action-card" href="<?= h($action['href']) ?>">
                    <strong><?= h($action['title']) ?></strong>
                    <span><?= h($action['desc']) ?></span>
                  </a>
                <?php endforeach; ?>
              </div>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>最近活动</h2>
                  <p class="section-desc">团队最近的通知协作动态。</p>
                </div>
              </div>
              <ul class="activity-list">
                <?php foreach ($activities as $activity): ?>
                  <li><?= h($activity) ?></li>
                <?php endforeach; ?>
              </ul>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>工作提醒</h2>
                  <p class="section-desc">运营空间内的待办提示。</p>
                </div>
              </div>
              <ul class="check-list">
                <?php foreach ($alerts as $alert): ?>
                  <li><?= h($alert) ?></li>
                <?php endforeach; ?>
              </ul>
            </section>
          </aside>
        </section>
      </main>
    </div>
  </div>
</body>
</html>
