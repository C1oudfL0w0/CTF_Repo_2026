<?php

declare(strict_types=1);

require __DIR__ . '/_init.php';

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$records = [
    ['title' => '积分商城维护公告', 'category' => '活动运营', 'status' => '已发布', 'channel' => '企业微信 / 邮件', 'time' => '昨天 09:20', 'owner' => '陈璇'],
    ['title' => '华东区域服务时间变更', 'category' => '系统通知', 'status' => '待审核', 'channel' => '站内信 / 企业微信', 'time' => '今天 08:15', 'owner' => '林默'],
    ['title' => '春节会员权益调整通知', 'category' => '会员权益', 'status' => '草稿', 'channel' => '邮件 / 站内信', 'time' => '今天 10:40', 'owner' => '林默'],
    ['title' => '客户服务渠道升级说明', 'category' => '客户服务', 'status' => '已归档', 'channel' => '企业微信', 'time' => '前天 17:05', 'owner' => '王启'],
];

$logs = [
    '林默提交了《华东区域服务时间变更》审核申请',
    '陈璇确认《积分商城维护公告》发布完成',
    '王启更新了客户服务片段「热线与工单」',
    '运营管理员归档了 2026 年 8 月已发布记录',
];

$stats = [
    ['label' => '本月发布', 'value' => '128'],
    ['label' => '待审核', 'value' => '4'],
    ['label' => '已归档', 'value' => '31'],
];
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>发布记录 - NorthLine 通知编排中心</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="app-body">
  <div class="shell">
    <aside class="app-sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">NL</div>
        <div class="brand-text">
          <strong>NorthLine</strong>
          <span>通知编排中心</span>
        </div>
      </div>

      <nav class="nav-group">
        <a class="nav-item" href="/">工作台</a>
        <a class="nav-item" href="/draft.php">通知草稿</a>
        <a class="nav-item" href="/draft.php">发布预览</a>
        <a class="nav-item" href="/upload.php">共享片段</a>
        <a class="nav-item active" href="/records.php">发布记录</a>
      </nav>

      <div class="nav-caption">团队空间</div>
      <nav class="nav-group nav-group-secondary">
        <a class="nav-item" href="/records.php">成员与权限</a>
        <a class="nav-item" href="/records.php">操作日志</a>
      </nav>

      <div class="sidebar-footer">
        <p>当前空间：市场运营组</p>
        <p>版本：2026.08</p>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-header">
        <div class="breadcrumb-block">
          <p class="breadcrumb">通知编排中心 / 发布记录</p>
          <h1 class="page-title">发布记录</h1>
        </div>

        <label class="search-box" aria-label="搜索通知、模板或片段">
          <span>搜索通知、模板或片段</span>
          <input type="search" placeholder="搜索通知、模板或片段">
        </label>

        <div class="header-actions">
          <a class="help-link" href="#">帮助</a>
          <div class="user-card">
            <div class="user-avatar">林</div>
            <div>
              <strong>林默</strong>
              <p>运营管理员</p>
            </div>
          </div>
        </div>
      </header>

      <main class="page-content">
        <section class="panel hero-panel">
          <div>
            <p class="eyebrow">发布中心</p>
            <h2>查看通知发布状态、渠道覆盖与审批流转</h2>
            <p class="section-desc">记录已发布、待审核与已归档通知，便于追踪团队协作进度。</p>
          </div>
          <div class="button-row">
            <a class="btn btn-primary" href="/draft.php">新建通知</a>
            <a class="btn btn-secondary" href="/upload.php">导入共享片段</a>
          </div>
        </section>

        <section class="stat-grid stat-grid--three">
          <?php foreach ($stats as $item): ?>
            <article class="panel stat-card">
              <span class="stat-label"><?= h($item['label']) ?></span>
              <strong><?= h($item['value']) ?></strong>
            </article>
          <?php endforeach; ?>
        </section>

        <section class="dashboard-grid dashboard-grid--records">
          <section class="panel table-panel">
            <div class="section-head">
              <div>
                <h2>发布记录</h2>
                <p class="section-desc">当前空间最近的通知流转情况。</p>
              </div>
            </div>

            <div class="table-wrap">
              <table class="records-table">
                <thead>
                  <tr>
                    <th>通知标题</th>
                    <th>分类</th>
                    <th>状态</th>
                    <th>渠道</th>
                    <th>更新时间</th>
                    <th>负责人</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($records as $row): ?>
                    <?php $statusClass = match ($row['status']) {
                        '草稿' => 'draft',
                        '待审核' => 'pending',
                        '已发布' => 'published',
                        '已归档' => 'archived',
                        default => 'draft',
                    }; ?>
                    <tr>
                      <td><?= h($row['title']) ?></td>
                      <td><?= h($row['category']) ?></td>
                      <td><span class="status-tag status-tag--<?= h($statusClass) ?>"><?= h($row['status']) ?></span></td>
                      <td><?= h($row['channel']) ?></td>
                      <td><?= h($row['time']) ?></td>
                      <td><?= h($row['owner']) ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </section>

          <aside class="stacked-panels">
            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>操作日志</h2>
                  <p class="section-desc">团队最近的发布协作动态。</p>
                </div>
              </div>
              <ul class="activity-list">
                <?php foreach ($logs as $log): ?>
                  <li><?= h($log) ?></li>
                <?php endforeach; ?>
              </ul>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>流程提示</h2>
                  <p class="section-desc">常见的发布协作步骤。</p>
                </div>
              </div>
              <ul class="check-list">
                <li>草稿页完成内容编写后进入预览。</li>
                <li>确认渠道配置后再提交审核。</li>
                <li>发布后及时归档记录并保留版本说明。</li>
              </ul>
            </section>
          </aside>
        </section>
      </main>
    </div>
  </div>
</body>
</html>
