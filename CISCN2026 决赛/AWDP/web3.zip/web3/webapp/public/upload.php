<?php

declare(strict_types=1);

require __DIR__ . '/_init.php';

use App\NoticeUploadService;

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $record = (new NoticeUploadService())->store($_FILES['file'] ?? [], APP_UPLOAD_DIR);
        $_SESSION['snippets'] ??= [];
        $_SESSION['snippets'][] = $record;
        header('Location: /upload.php?ok=1');
        exit;
    } catch (\RuntimeException $e) {
        http_response_code($e->getMessage() === 'store-failed' ? 500 : 400);
        $errorMessage = '片段导入失败，请确认文件格式和大小符合要求。';
    }
}

$banner = null;
if (isset($_GET['ok'])) {
    $banner = ['type' => 'success', 'message' => '共享片段已导入，可在通知编辑器中使用。'];
} elseif (isset($errorMessage)) {
    $banner = ['type' => 'error', 'message' => $errorMessage];
}

$recentSnippets = array_reverse($_SESSION['snippets'] ?? []);
$recentSnippets = array_slice($recentSnippets, 0, 6);
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>导入共享片段 - NorthLine 通知编排中心</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="app-body">
  <div class="shell">
    <aside class="app-sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">NL</div>
        <div class="brand-text">
          <strong>NorthLine</strong>
          <span>通知编排中心</span>
        </div>
      </div>

      <nav class="nav-group">
        <a class="nav-item" href="/">工作台</a>
        <a class="nav-item" href="/draft.php">通知草稿</a>
        <a class="nav-item" href="/draft.php">发布预览</a>
        <a class="nav-item active" href="/upload.php">共享片段</a>
        <a class="nav-item" href="/records.php">发布记录</a>
      </nav>

      <div class="nav-caption">团队空间</div>
      <nav class="nav-group nav-group-secondary">
        <a class="nav-item" href="/records.php">成员与权限</a>
        <a class="nav-item" href="/records.php">操作日志</a>
      </nav>

      <div class="sidebar-footer">
        <p>当前空间：市场运营组</p>
        <p>版本：2026.08</p>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-header">
        <div class="breadcrumb-block">
          <p class="breadcrumb">通知编排中心 / 共享片段</p>
          <h1 class="page-title">导入共享片段</h1>
        </div>

        <label class="search-box" aria-label="搜索通知、模板或片段">
          <span>搜索通知、模板或片段</span>
          <input type="search" placeholder="搜索通知、模板或片段">
        </label>

        <div class="header-actions">
          <a class="help-link" href="#">帮助</a>
          <div class="user-card">
            <div class="user-avatar">林</div>
            <div>
              <strong>林默</strong>
              <p>运营管理员</p>
            </div>
          </div>
        </div>
      </header>

      <main class="page-content">
        <?php if ($banner !== null): ?>
          <section class="state-banner state-banner--<?= h($banner['type']) ?>">
            <?= h($banner['message']) ?>
          </section>
        <?php endif; ?>

        <section class="panel hero-panel">
          <div>
            <p class="eyebrow">共享片段库</p>
            <h2>导入团队常用通知内容，统一后续复用口径</h2>
            <p class="section-desc">将团队常用的通知内容导入片段库，方便在后续通知中复用。</p>
          </div>
          <div class="button-row">
            <a class="btn btn-secondary" href="/draft.php">返回草稿</a>
            <a class="btn btn-secondary" href="/">返回工作台</a>
          </div>
        </section>

        <section class="upload-page-grid">
          <section class="panel">
            <div class="section-head">
              <div>
                <h2>片段信息</h2>
                <p class="section-desc">支持导入 TXT 格式的通知片段，单个文件不超过 50 KB。</p>
              </div>
            </div>

            <form action="/upload.php" method="post" enctype="multipart/form-data" class="draft-form">
              <div class="field-grid">
                <label>
                  <span>片段名称</span>
                  <input type="text" name="snippet_name" placeholder="例如：客户服务热线说明">
                </label>
                <label>
                  <span>片段分类</span>
                  <select name="snippet_category">
                    <option>客户服务</option>
                    <option>活动运营</option>
                    <option>系统通知</option>
                    <option>会员权益</option>
                    <option>渠道说明</option>
                  </select>
                </label>
                <label>
                  <span>适用场景</span>
                  <input type="text" name="scenario" placeholder="例如：活动上线前统一客服口径">
                </label>
                <label>
                  <span>内容文件</span>
                  <input type="file" name="file" accept=".txt,text/plain" required>
                </label>
              </div>

              <label>
                <span>备注</span>
                <textarea name="remark" rows="5" placeholder="可填写片段适用渠道、更新背景或维护说明。"></textarea>
              </label>

              <div class="form-actions">
                <button type="submit" class="btn btn-primary">导入片段</button>
                <a class="btn btn-secondary" href="/draft.php">取消</a>
              </div>
            </form>
          </section>

          <aside class="stacked-panels">
            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>导入说明</h2>
                  <p class="section-desc">建议导入便于复用的纯文本通知片段。</p>
                </div>
              </div>
              <ul class="check-list">
                <li>适合导入客服说明、活动提醒、统一落款等内容。</li>
                <li>导入完成后，可在通知编辑器中生成预览。</li>
                <li>如需更新内容，请重新导入最新版本文件。</li>
              </ul>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>最近导入</h2>
                  <p class="section-desc">当前空间最近导入的共享片段。</p>
                </div>
              </div>
              <?php if ($recentSnippets === []): ?>
                <div class="empty-card">
                  <strong>暂无导入记录</strong>
                  <p>完成导入后，片段会显示在这里并同步到工作台。</p>
                </div>
              <?php else: ?>
                <div class="snippet-list">
                  <?php foreach ($recentSnippets as $item): ?>
                    <article class="snippet-item">
                      <div>
                        <strong><?= h((string)($item['name'] ?? '未命名片段')) ?></strong>
                        <p><?= h((string)($item['uploaded_at'] ?? '-')) ?></p>
                      </div>
                      <span><?= h((string)($item['size'] ?? '0')) ?> B</span>
                    </article>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </section>
          </aside>
        </section>
      </main>
    </div>
  </div>
</body>
</html>
