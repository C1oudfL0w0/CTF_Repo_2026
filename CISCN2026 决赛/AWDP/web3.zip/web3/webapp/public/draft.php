<?php

declare(strict_types=1);

require __DIR__ . '/_init.php';

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$templateMode = (string)($_GET['template'] ?? '');

$defaults = [
    'subject' => '春节会员权益调整通知',
    'category' => '会员权益',
    'audience' => '会员中心、客户服务、区域运营负责人',
    'severity' => 'P2',
    'planned_window' => date('Y-m-d') . ' 10:00 - 12:00',
    'operator_name' => '林默',
    'operator_email' => 'linmo@northline.local',
    'summary' => '结合节前活动节奏，对会员权益说明、积分到账时效和客户服务响应口径进行统一更新，确保各渠道文案一致并便于审核发布。',
];

$templates = [
    'service' => [
        'title' => '服务变更通知',
        'subject' => '华东区域服务时间变更通知',
        'category' => '系统通知',
        'summary' => '因区域值班安排调整，相关服务窗口将在指定时段更新，请各业务团队确认对外口径并及时同步负责人。',
    ],
    'event' => [
        'title' => '活动运营公告',
        'subject' => '积分商城活动上线公告',
        'category' => '活动运营',
        'summary' => '围绕活动上线节点，统一更新公告文案、渠道说明与客服答复口径，确保外发内容一致。',
    ],
    'rights' => [
        'title' => '客户权益说明',
        'subject' => '春节会员权益调整通知',
        'category' => '会员权益',
        'summary' => '结合节前活动节奏，对会员权益说明、积分到账时效和客户服务响应口径进行统一更新。',
    ],
];

if (isset($templates[$templateMode])) {
    $defaults['subject'] = $templates[$templateMode]['subject'];
    $defaults['category'] = $templates[$templateMode]['category'];
    $defaults['summary'] = $templates[$templateMode]['summary'];
}

$defaultTemplate = <<<'TWIG'
<section class="notice-mail">
  <header class="notice-mail__header">
    <p class="notice-mail__badge">{{ delivery.severity }} · {{ workspace.name }}</p>
    <h2>{{ bulletin.subject }}</h2>
    <p class="notice-mail__meta">通知分类：{{ bulletin.category }} ｜ 目标对象：{{ delivery.audience }}</p>
  </header>

  <p>各位同事：</p>
  <p>{{ bulletin.summary }}</p>

  <ul class="notice-mail__list">
    <li>发布渠道：{{ delivery.channel }}</li>
    <li>计划窗口：{{ delivery.window }}</li>
    <li>内容标签：{{ labels|join(' / ') }}</li>
  </ul>

  <p>请各业务线在发布前完成最终校对，确保对外口径、联系人信息和通知时效保持一致。</p>

  <footer class="notice-mail__footer">
    <p>{{ workspace.signature }}</p>
    <p>{{ operator.name }} · {{ operator.email }}</p>
  </footer>
</section>
TWIG;

$recentSnippets = array_reverse($_SESSION['snippets'] ?? []);
$recentSnippets = array_slice($recentSnippets, 0, 6);

$banner = null;
if (isset($_GET['import'])) {
    $banner = ['type' => 'info', 'message' => '已导入共享片段，可在正文中复用。'];
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>通知草稿 - NorthLine 通知编排中心</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body class="app-body">
  <div class="shell">
    <aside class="app-sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">NL</div>
        <div class="brand-text">
          <strong>NorthLine</strong>
          <span>通知编排中心</span>
        </div>
      </div>

      <nav class="nav-group">
        <a class="nav-item" href="/">工作台</a>
        <a class="nav-item active" href="/draft.php">通知草稿</a>
        <a class="nav-item" href="/draft.php">发布预览</a>
        <a class="nav-item" href="/upload.php">共享片段</a>
        <a class="nav-item" href="/records.php">发布记录</a>
      </nav>

      <div class="nav-caption">团队空间</div>
      <nav class="nav-group nav-group-secondary">
        <a class="nav-item" href="/records.php">成员与权限</a>
        <a class="nav-item" href="/records.php">操作日志</a>
      </nav>

      <div class="sidebar-footer">
        <p>当前空间：市场运营组</p>
        <p>版本：2026.08</p>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-header">
        <div class="breadcrumb-block">
          <p class="breadcrumb">通知编排中心 / 通知草稿</p>
          <h1 class="page-title">通知草稿</h1>
        </div>

        <label class="search-box" aria-label="搜索通知、模板或片段">
          <span>搜索通知、模板或片段</span>
          <input type="search" placeholder="搜索通知、模板或片段">
        </label>

        <div class="header-actions">
          <a class="help-link" href="#">帮助</a>
          <div class="user-card">
            <div class="user-avatar">林</div>
            <div>
              <strong>林默</strong>
              <p>运营管理员</p>
            </div>
          </div>
        </div>
      </header>

      <main class="page-content">
        <?php if ($banner !== null): ?>
          <section class="state-banner state-banner--<?= h($banner['type']) ?>">
            <?= h($banner['message']) ?>
          </section>
        <?php endif; ?>

        <section class="panel hero-panel">
          <div>
            <p class="eyebrow">草稿编辑区</p>
            <h2>编写通知内容并生成渠道预览</h2>
            <p class="section-desc">填写标题、分类、摘要与正文模板后，可直接生成预览并进入审核流程。</p>
          </div>
          <div class="button-row">
            <a class="btn btn-secondary" href="/">返回工作台</a>
            <a class="btn btn-secondary" href="/upload.php">导入共享片段</a>
          </div>
        </section>

        <section class="editor-grid">
          <section class="panel">
            <div class="section-head">
              <div>
                <h2>草稿编辑</h2>
                <p class="section-desc">填写基础信息并生成当前通知在不同渠道中的展示效果。</p>
              </div>
            </div>

            <form action="/preview.php" method="post" class="draft-form" id="draft-form">
              <div class="field-grid">
                <label>
                  <span>通知标题</span>
                  <input type="text" name="subject" value="<?= h($defaults['subject']) ?>">
                </label>
                <label>
                  <span>通知分类</span>
                  <select name="category">
                    <?php foreach (['客户服务', '活动运营', '系统通知', '会员权益', '渠道说明'] as $category): ?>
                      <option value="<?= h($category) ?>" <?= $category === $defaults['category'] ? 'selected' : '' ?>><?= h($category) ?></option>
                    <?php endforeach; ?>
                  </select>
                </label>
                <label>
                  <span>目标对象</span>
                  <input type="text" name="audience" value="<?= h($defaults['audience']) ?>">
                </label>
                <label>
                  <span>内容状态</span>
                  <select name="severity">
                    <?php foreach (['P1', 'P2', 'P3'] as $level): ?>
                      <option value="<?= h($level) ?>" <?= $level === $defaults['severity'] ? 'selected' : '' ?>><?= h($level) ?></option>
                    <?php endforeach; ?>
                  </select>
                </label>
                <label>
                  <span>更新时间</span>
                  <input type="text" name="planned_window" value="<?= h($defaults['planned_window']) ?>">
                </label>
                <label>
                  <span>最近编辑</span>
                  <input type="text" name="operator_name" value="<?= h($defaults['operator_name']) ?>">
                </label>
                <label>
                  <span>联系邮箱</span>
                  <input type="email" name="operator_email" value="<?= h($defaults['operator_email']) ?>">
                </label>
              </div>

              <label>
                <span>通知摘要</span>
                <textarea name="summary" rows="5"><?= h($defaults['summary']) ?></textarea>
              </label>

              <label>
                <span>通知正文</span>
                <textarea name="tpl" rows="18" class="template-area" spellcheck="false"><?= h($defaultTemplate) ?></textarea>
              </label>

              <div class="form-actions">
                <button type="submit" class="btn btn-primary">生成预览</button>
                <p>建议先检查标题、对象、渠道与联系人信息，再提交审核。</p>
              </div>
            </form>
          </section>

          <aside class="stacked-panels">
            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>常用模板</h2>
                  <p class="section-desc">复用企业常见通知结构，减少重复录入。</p>
                </div>
              </div>
              <div class="action-list">
                <?php foreach ($templates as $key => $template): ?>
                  <a class="action-card" href="/draft.php?template=<?= h($key) ?>#draft-form">
                    <strong><?= h($template['title']) ?></strong>
                    <span><?= h($template['summary']) ?></span>
                  </a>
                <?php endforeach; ?>
              </div>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>共享片段</h2>
                  <p class="section-desc">最近导入的团队共享内容。</p>
                </div>
              </div>
              <?php if ($recentSnippets === []): ?>
                <div class="empty-card">
                  <strong>暂无共享片段</strong>
                  <p>可先导入客服说明、活动提示或统一落款等常用内容。</p>
                </div>
              <?php else: ?>
                <div class="snippet-list">
                  <?php foreach ($recentSnippets as $item): ?>
                    <article class="snippet-item">
                      <div>
                        <strong><?= h((string)($item['name'] ?? '未命名片段')) ?></strong>
                        <p><?= h((string)($item['uploaded_at'] ?? '-')) ?></p>
                      </div>
                      <span><?= h((string)($item['size'] ?? '0')) ?> B</span>
                    </article>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </section>

            <section class="panel">
              <div class="section-head">
                <div>
                  <h2>发布前检查</h2>
                  <p class="section-desc">提交审核前请完成以下校对。</p>
                </div>
              </div>
              <ul class="check-list">
                <li>确认通知标题、摘要与目标对象一致。</li>
                <li>检查计划窗口、联系人与渠道配置。</li>
                <li>预览后再提交审核，避免多版本文案混用。</li>
              </ul>
            </section>
          </aside>
        </section>
      </main>
    </div>
  </div>
</body>
</html>
