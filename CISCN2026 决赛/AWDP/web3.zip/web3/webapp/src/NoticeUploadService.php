<?php

declare(strict_types=1);

namespace App;

final class NoticeUploadService
{
    /**
     * @param array<string, mixed> $file
     * @return array{path:string,name:string,size:string,uploaded_at:string}
     */
    public function store(array $file, string $uploadDir): array
    {
        $name = (string)($file['name'] ?? '');
        $tmp = (string)($file['tmp_name'] ?? '');
        $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        $size = (int)($file['size'] ?? 0);

        if ($error !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) {
            throw new \RuntimeException('upload-failed');
        }

        if ($size > 50 * 1024) {
            throw new \RuntimeException('file-too-large');
        }

        if (!preg_match('/\.txt$/i', $name)) {
            throw new \RuntimeException('invalid-extension');
        }

        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', basename($name));
        $dest = rtrim($uploadDir, '/') . '/' . bin2hex(random_bytes(4)) . '_' . $safeName;

        if (!move_uploaded_file($tmp, $dest)) {
            throw new \RuntimeException('store-failed');
        }

        return [
            'path' => $dest,
            'name' => $safeName,
            'size' => (string)$size,
            'uploaded_at' => date('Y-m-d H:i:s'),
        ];
    }
}
