<?php

declare(strict_types=1);

namespace App;

class NoticeFragment implements \Stringable
{
    public function __construct(
        private readonly string $sourceFile,
        private readonly string $displayName,
    ) {
    }

    public function displayName(): string
    {
        return $this->displayName;
    }

    public function sourceFile(): string
    {
        return $this->sourceFile;
    }

    public function __toString(): string
    {
        if (!is_file($this->sourceFile)) {
            return '';
        }

        ob_start();
        include $this->sourceFile;
        return trim((string) ob_get_clean());
    }
}
