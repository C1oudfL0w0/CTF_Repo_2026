<?php

declare(strict_types=1);

namespace App;

class TwigFactory extends NoticeTemplateEngine
{
}
