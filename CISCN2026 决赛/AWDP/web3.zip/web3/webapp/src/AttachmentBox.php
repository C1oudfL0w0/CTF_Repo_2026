<?php

declare(strict_types=1);

namespace App;

class AttachmentBox extends NoticeFragmentCollection
{
    /**
     * @param array<int, array{path:string, name:string}> $items
     */
    public function __construct(array $items)
    {
        $fragments = [];
        foreach ($items as $item) {
            if (!isset($item['path'], $item['name'])) {
                continue;
            }

            $fragments[] = new Attachment((string)$item['path'], (string)$item['name']);
        }

        parent::__construct($fragments);
    }
}
