<?php

declare(strict_types=1);

namespace App;

final class Attachment extends NoticeFragment
{
}
