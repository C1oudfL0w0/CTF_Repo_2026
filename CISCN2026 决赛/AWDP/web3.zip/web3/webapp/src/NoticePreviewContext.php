<?php

declare(strict_types=1);

namespace App;

final class NoticePreviewContext
{
    public function __construct(
        private readonly NoticePreviewInput $input,
        private readonly NoticeFragmentCollection $fragments,
    ) {
    }

    public function toArray(): array
    {
        return [
            'workspace' => [
                'name' => 'NorthLine 通知编排中心',
                'signature' => 'NorthLine 市场运营组',
            ],
            'bulletin' => [
                'subject' => $this->input->subject(),
                'summary' => $this->input->summary(),
                'category' => $this->input->category(),
            ],
            'delivery' => [
                'audience' => $this->input->audience(),
                'window' => $this->input->plannedWindow(),
                'severity' => $this->input->severity(),
                'channel' => '企业微信 / 邮件 / 站内信',
            ],
            'operator' => [
                'name' => $this->input->operatorName(),
                'email' => $this->input->operatorEmail(),
            ],
            'snippet_count' => count($this->fragments),
            'snippets' => $this->fragments,
            'labels' => ['运营通知', '渠道同步', '内部发布'],
        ];
    }
}
