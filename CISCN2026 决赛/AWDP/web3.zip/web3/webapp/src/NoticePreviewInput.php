<?php

declare(strict_types=1);

namespace App;

final class NoticePreviewInput
{
    public function __construct(
        private readonly string $template,
        private readonly string $subject,
        private readonly string $category,
        private readonly string $audience,
        private readonly string $severity,
        private readonly string $plannedWindow,
        private readonly string $operatorName,
        private readonly string $operatorEmail,
        private readonly string $summary,
    ) {
    }

    public static function fromRequest(array $data): self
    {
        return new self(
            (string)($data['tpl'] ?? ''),
            trim((string)($data['subject'] ?? '春节会员权益调整通知')),
            trim((string)($data['category'] ?? '会员权益')),
            trim((string)($data['audience'] ?? '会员中心、客户服务、区域运营负责人')),
            trim((string)($data['severity'] ?? 'P2')),
            trim((string)($data['planned_window'] ?? (date('Y-m-d') . ' 10:00 - 12:00'))),
            trim((string)($data['operator_name'] ?? '林默')),
            trim((string)($data['operator_email'] ?? 'linmo@northline.local')),
            trim((string)($data['summary'] ?? '结合节前活动节奏，对会员权益说明、积分到账时效和客户服务响应口径进行统一更新，确保各渠道文案一致并便于审核发布。')),
        );
    }

    public function template(): string
    {
        return $this->template;
    }

    public function subject(): string
    {
        return $this->subject;
    }

    public function category(): string
    {
        return $this->category;
    }

    public function audience(): string
    {
        return $this->audience;
    }

    public function severity(): string
    {
        return $this->severity;
    }

    public function plannedWindow(): string
    {
        return $this->plannedWindow;
    }

    public function operatorName(): string
    {
        return $this->operatorName;
    }

    public function operatorEmail(): string
    {
        return $this->operatorEmail;
    }

    public function summary(): string
    {
        return $this->summary;
    }
}
