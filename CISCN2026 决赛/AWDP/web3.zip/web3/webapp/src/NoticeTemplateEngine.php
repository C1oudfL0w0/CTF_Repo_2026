<?php

declare(strict_types=1);

namespace App;

use Twig\Environment;
use Twig\Extension\SandboxExtension;
use Twig\Loader\ArrayLoader;
use Twig\Sandbox\SecurityPolicy;

class NoticeTemplateEngine
{
    public static function render(string $template, array $context = []): string
    {
        $loader = new ArrayLoader(['preview' => $template]);
        $twig = new Environment($loader, [
            'autoescape' => 'html',
            'cache' => false,
            'strict_variables' => false,
        ]);

        $policy = new SecurityPolicy(
            [],
            ['escape', 'e', 'join', 'replace', 'length', 'lower', 'upper', 'default', 'slice'],
            [],
            [],
            []
        );

        $twig->addExtension(new SandboxExtension($policy, true));

        return $twig->render('preview', $context);
    }
}
