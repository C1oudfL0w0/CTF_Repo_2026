<?php

declare(strict_types=1);

namespace App;

class NoticeFragmentCollection implements \IteratorAggregate, \Countable
{
    /**
     * @param array<int, NoticeFragment> $items
     */
    public function __construct(private array $items)
    {
    }

    /**
     * @param array<int, array{path?:string,name?:string}> $records
     */
    public static function fromRecords(array $records): self
    {
        $items = [];
        foreach ($records as $record) {
            if (!isset($record['path'], $record['name'])) {
                continue;
            }

            $items[] = new NoticeFragment((string)$record['path'], (string)$record['name']);
        }

        return new self($items);
    }

    public function getIterator(): \Traversable
    {
        yield from $this->items;
    }

    public function count(): int
    {
        return count($this->items);
    }
}
