<?php

declare(strict_types=1);

namespace App;

final class NoticePreviewRenderer
{
    public function render(NoticePreviewInput $input, NoticeFragmentCollection $fragments): string
    {
        $context = (new NoticePreviewContext($input, $fragments))->toArray();
        return NoticeTemplateEngine::render($input->template(), $context);
    }
}
