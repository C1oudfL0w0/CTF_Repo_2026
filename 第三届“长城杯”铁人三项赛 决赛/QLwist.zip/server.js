'use strict';

const express        = require('express');
const { ApolloServer }       = require('@apollo/server');
const { expressMiddleware }  = require('@apollo/server/express4');
const { ApolloServerPluginLandingPageDisabled } = require('@apollo/server/plugin/disabled');
const rateLimit      = require('express-rate-limit');
const cookieParser   = require('cookie-parser');
const path           = require('path');
const vm             = require('vm');

const { typeDefs, resolvers, USERS, hashPw } = require('./schema');
const { verifyToken, signToken }              = require('./auth');

const app  = express();
const PORT = 5000;

app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

function authMiddleware(req, _res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.replace(/^Bearer\s+/i, '').trim()
              || req.cookies?.token;
  req.user = token ? verifyToken(token) : null;
  next();
}

function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    next();
  };
}

function requireUser(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: '请先登录' });
  }
  next();
}

app.use(authMiddleware);

const gqlLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { errors: [{ message: 'Rate limit exceeded. Try again later.' }] },
  standardHeaders: true,
  legacyHeaders:   false,
  skip: (req) => {
    const body = req.body;
    if (!body || typeof body !== 'object' || Array.isArray(body)) return false;
    if (!body.query || typeof body.query !== 'string') return false;
    const q = body.query.trim().toLowerCase();
    if (!q.startsWith('query')) return false;
    if (q.includes('mutation')) return false;
    return true;
  },
});

const linkCheckLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  message: { error: 'Too many requests. Please try again later.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

async function startServer() {
  const apollo = new ApolloServer({
    typeDefs,
    resolvers,
    introspection: true,
    hideSchemaDetailsFromClientErrors: true,
    includeStacktraceInErrorResponses: false,
    formatError(formattedError) {
      return { message: formattedError.message };
    },
    plugins: [ApolloServerPluginLandingPageDisabled()],
  });

  await apollo.start();

  app.use('/graphql', (req, res, next) => {
    const ip = req.ip || req.socket?.remoteAddress || '';
    if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(ip)) {
      return res.status(403).json({
        errors: [{ message: 'GraphQL API is for internal use only.' }],
      });
    }

    if (Array.isArray(req.body)) {
      return res.status(400).json({
        errors: [{ message: 'Batch requests are not supported.' }],
      });
    }

    const query = req.body?.query || '';
    if (/__schema\b/i.test(query)) {
      return res.status(400).json({
        errors: [{ message: 'Introspection is not allowed.' }],
      });
    }

    next();
  }, gqlLimiter, expressMiddleware(apollo, {
    context: async ({ req }) => ({ user: req.user }),
  }));

  app.get('/', (req, res) => {
    if (req.user) return res.redirect('/dashboard');
    res.render('index');
  });

  app.post('/auth/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
    const user = USERS[username];
    if (!user || user.passwordHash !== hashPw(password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = signToken({ username, role: user.role });
    res.json({ token, username, role: user.role });
  });

  app.post('/auth/register', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
    if (username === 'admin') return res.status(400).json({ error: 'Reserved username' });
    if (USERS[username]) return res.status(409).json({ error: 'Username already exists' });
    USERS[username] = { passwordHash: hashPw(password), role: 'user' };
    const token = signToken({ username, role: 'user' });
    res.json({ token, username, role: 'user' });
  });

  app.get('/dashboard', (req, res) => {
    if (!req.user) return res.redirect('/');
    res.render('dashboard', { user: req.user });
  });

  app.get('/profile', (req, res) => {
    if (!req.user) return res.redirect('/');
    res.render('profile', { user: req.user });
  });

  app.get('/admin', requireRole('admin', 'super_admin'), (req, res) => {
    res.render('admin', { user: req.user });
  });

  app.get('/admin/super', requireRole('super_admin'), (req, res) => {
    res.render('super_admin', { user: req.user });
  });

  const EXPR_DISALLOWED = [
    'prototype',
    'require', 'exec', 'spawn', 'child', 'process',
    'module', 'binding', 'dlopen',
    'global', 'import',
  ];

  function validateExpression(code) {
    for (const token of EXPR_DISALLOWED) {
      if (code.includes(token)) return false;
    }
    return true;
  }

  app.post('/admin/super/evaluate', requireRole('super_admin'), (req, res) => {
    const { expression } = req.body;
    if (typeof expression !== 'string' || expression.length > 4096) {
      return res.status(400).json({ error: 'Invalid expression' });
    }

    if (!validateExpression(expression)) {
      return res.status(400).json({ error: 'Expression contains disallowed identifiers' });
    }

    const ctx = { result: undefined, Math, JSON };
    const _p = globalThis.process;
    const _b = globalThis.Buffer;
    delete globalThis.process;
    delete globalThis.Buffer;

    let value;
    try {
      vm.runInNewContext(
        `result = (() => { ${expression} })()`,
        ctx,
        { timeout: 2000 },
      );
      value = String(ctx.result ?? '');
    } catch (e) {
      value = `Error: ${e.message}`;
    } finally {
      globalThis.process = _p;
      globalThis.Buffer = _b;
    }

    return res.json({ value });
  });

  app.post('/api/link-check', requireUser, linkCheckLimiter, async (req, res) => {
    const reqBody = req.body;
    if (!reqBody || typeof reqBody !== 'object' || Array.isArray(reqBody)) {
      return res.status(400).json({ error: 'Invalid body' });
    }
    const { url, method: methodRaw, headers: extraHeaders = {}, body: jsonBody } = reqBody;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: 'url is required' });
    }
    const method = (methodRaw == null || methodRaw === '') ? 'GET' : String(methodRaw).toUpperCase();

    try {
      if (method === 'GET') {
        const response = await fetch(url, {
          method: 'GET',
          headers: { 'User-Agent': 'IntraPortal-LinkCheck/1.0' },
          redirect: 'follow',
        });
        const text = await response.text();
        return res.json({ status: response.status, body: text });
      }

      if (['POST', 'PUT', 'PATCH'].includes(method)) {
        if (jsonBody === undefined || jsonBody === null) {
          return res.status(400).json({ error: 'body is required for POST/PUT/PATCH' });
        }
        const init = {
          method,
          headers: { 'Content-Type': 'application/json', ...extraHeaders },
          body: typeof jsonBody === 'string' ? jsonBody : JSON.stringify(jsonBody),
        };
        const response = await fetch(url, init);
        const text = await response.text();
        return res.json({ status: response.status, body: text });
      }

      return res.status(400).json({ error: 'Unsupported method' });
    } catch (e) {
      return res.json({ error: String(e.message) });
    }
  });

  app.get('/health', (_req, res) => res.json({
    status: 'ok',
    services: { api: 'public', graphql: 'internal' },
  }));

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[server] listening on :${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[server] fatal:', err);
  process.exit(1);
});
