use solana_sdk::{
    account::Account,
    compute_budget::ComputeBudgetInstruction,
    instruction::Instruction,
    pubkey::Pubkey,
    signature::{Keypair, Signer},
};

use anchor_lang::AccountDeserialize;
use anchor_lang::{system_program, InstructionData, ToAccountMetas};
use solana_sdk::account::ReadableAccount;

use sol_ctf_framework::ChallengeBuilder;

use std::{
    env,
    error::Error,
    io::Write,
    net::{TcpListener, TcpStream},
    time::{SystemTime, UNIX_EPOCH},
};

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:1337")?;

    println!("Server listening on port 1337");

    for stream in listener.incoming() {
        let mut stream = stream.unwrap();

        tokio::spawn(async move {
            if let Err(err) = handle_connection(&mut stream).await {
                writeln!(stream, "error: {:?}", err).ok();
            }
        });
    }
    Ok(())
}

async fn handle_connection(socket: &mut TcpStream) -> Result<(), Box<dyn Error>> {
    let mut builder = ChallengeBuilder::try_from(socket.try_clone()?)?;

    let solve_id = match builder.input_program() {
        Ok(pubkey) => pubkey,
        Err(e) => {
            writeln!(socket, "Error: cannot load player program -> {e}")?;
            return Ok(());
        }
    };
    let chall_id = builder
        .add_program("./challenge.so", Some(challenge::id()))
        .expect("Duplicate pubkey supplied");

    writeln!(socket, "Challenge: {}", chall_id)?;
    writeln!(socket, "Exploit: {}", solve_id)?;

    let admin_keypair = Keypair::new();
    let admin = admin_keypair.pubkey();
    builder
        .builder
        .add_account(admin, Account::new(100_000_000_000, 0, &system_program::ID));

    let vault = Pubkey::find_program_address(&[b"vault"], &chall_id).0;
    builder
        .builder
        .add_account(vault, Account::new(100_000_000_000, 0, &system_program::ID));

    let player = Keypair::new();
    builder.builder.add_account(
        player.pubkey(),
        Account::new(100_000_000, 0, &system_program::ID),
    );

    writeln!(socket, "Admin: {}", admin)?;
    writeln!(socket, "Player: {}", player.pubkey())?;
    writeln!(socket, "")?;

    let mut chall = builder.build().await;

    let current_time = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs() as i64;

    let auction = Pubkey::find_program_address(
        &[b"auction", admin.as_ref(), &1u64.to_le_bytes()],
        &chall_id,
    )
    .0;
    {
        let ix = challenge::instruction::CreateAuction {
            auction_id: 1,
            product: "flag".to_string(),
            buy_now_price: 10_000_000_000,         // 10 SOL
            starting_bid: 1_000_000_000,           // 1 SOL
            increment: 1_000_000_000,              // 1 SOL
            end_time: current_time + 24 * 60 * 60, // 24 hours
            settlement_deadline: current_time + 24 * 60 * 60 * 10,
        };
        let ix_accounts = challenge::accounts::CreateAuction {
            auctioneer: admin,
            auction,
            system_program: system_program::ID,
        };

        chall
            .run_ixs_full(
                &[Instruction::new_with_bytes(
                    chall_id,
                    &ix.data(),
                    ix_accounts.to_account_metas(None),
                )],
                &[&admin_keypair],
                &admin,
            )
            .await?;
    }

    let bidder_state =
        Pubkey::find_program_address(&[b"bidder", auction.as_ref(), admin.as_ref()], &chall_id).0;
    {
        let ix = challenge::instruction::PlaceBid {
            bid_amount: 1_000_000_000,
        };
        let ix_accounts = challenge::accounts::PlaceBid {
            bidder: admin,
            auction,
            vault,
            bidder_state,
            system_program: system_program::ID,
        };

        chall
            .run_ixs_full(
                &[Instruction::new_with_bytes(
                    chall_id,
                    &ix.data(),
                    ix_accounts.to_account_metas(None),
                )],
                &[&admin_keypair],
                &admin,
            )
            .await?;
    }

    let solve_ix = chall.read_instruction(solve_id)?;

    let bump_budget = ComputeBudgetInstruction::set_compute_unit_limit(10_000_000);

    chall
        .run_ixs_full(&[bump_budget, solve_ix], &[&player], &player.pubkey())
        .await?;

    let auction_state = challenge::Auction::try_deserialize(
        &mut chall
            .ctx
            .banks_client
            .get_account(auction)
            .await?
            .unwrap()
            .data(),
    )?;

    if auction_state.ended == true
        && auction_state.settled == true
        && auction_state.highest_bidder == player.pubkey()
    {
        writeln!(socket, "Auction ended! Here is your flag:")?;
        if let Ok(flag) = env::var("FLAG") {
            writeln!(socket, "flag: {:?}", flag)?;
        } else {
            writeln!(socket, "flag not found, please contact admin")?;
        }
        return Ok(());
    }

    writeln!(
        socket,
        "Thank you for using our auction platform! See you next time!"
    )?;

    Ok(())
}
