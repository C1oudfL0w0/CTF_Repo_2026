#![allow(unexpected_cfgs)]

use anchor_lang::prelude::InitSpace;
use anchor_lang::prelude::*;
use anchor_lang::system_program::transfer as system_transfer;

declare_id!("CR5narKTtujKJqS3H5hGTq2hkQTeSevjoyjLEMu4GSHR");

// Seed constants to keep PDAs deterministic across the program.
const VAULT_SEED: &[u8] = b"vault";
const AUCTION_SEED: &[u8] = b"auction";
const BIDDER_SEED: &[u8] = b"bidder";
const LAMPORTS_PER_SOL: u64 = 1_000_000_000;
const DEPOSIT_BPS: u64 = 2000;

#[program]
pub mod challenge {
    use super::*;

    /// Auctioneer creates an auction with product metadata and bidding rules.
    pub fn create_auction(
        ctx: Context<CreateAuction>,
        auction_id: u64,
        product: String,
        buy_now_price: u64,
        starting_bid: u64,
        increment: u64,
        end_time: i64,
        settlement_deadline: i64,
    ) -> Result<()> {
        require!(buy_now_price > 0, ErrorCode::InvalidPricing);
        require!(buy_now_price >= starting_bid, ErrorCode::InvalidPricing);
        require!(increment > 0, ErrorCode::InvalidIncrement);
        let now = Clock::get()?.unix_timestamp;
        require!(end_time >= now, ErrorCode::EndTimeInPast);
        require!(
            settlement_deadline >= end_time + 60 * 60 * 24 * 7,
            ErrorCode::InvalidSettlementDeadline
        );

        let auction = &mut ctx.accounts.auction;
        auction.auctioneer = ctx.accounts.auctioneer.key();
        auction.auction_id = auction_id;
        auction.product = product;
        auction.buy_now_price = buy_now_price;
        auction.starting_bid = starting_bid;
        auction.increment = increment;
        auction.deposit_amount = if starting_bid >= LAMPORTS_PER_SOL {
            starting_bid
                .checked_mul(DEPOSIT_BPS)
                .ok_or(ErrorCode::MathOverflow)?
                .checked_div(10000)
                .ok_or(ErrorCode::MathOverflow)?
        } else {
            0
        };
        auction.deposit_count = 0;
        auction.end_time = end_time;
        auction.settlement_deadline = settlement_deadline;
        auction.highest_bid = 0;
        auction.highest_bidder = Pubkey::default();
        auction.ended = false;
        auction.settled = false;
        auction.bump = ctx.bumps.auction;
        Ok(())
    }

    /// Place or raise a bid. Only a single deposit is locked up front.
    /// If buy-now is reached, the auction ends immediately and an event is emitted.
    pub fn place_bid(ctx: Context<PlaceBid>, bid_amount: u64) -> Result<()> {
        require!(bid_amount > 0, ErrorCode::InvalidBidAmount);
        let auction = &mut ctx.accounts.auction;

        let now = Clock::get()?.unix_timestamp;
        require!(
            !auction.ended && now < auction.end_time,
            ErrorCode::AuctionAlreadyEnded
        );
        require!(bid_amount >= auction.starting_bid, ErrorCode::BidTooLow);
        if auction.highest_bid > 0 {
            require!(
                bid_amount >= auction.highest_bid.saturating_add(auction.increment),
                ErrorCode::IncrementTooSmall
            );
        }

        // Pay deposit if required and not already paid.
        let bidder_state = &mut ctx.accounts.bidder_state;
        if !bidder_state.deposit_paid {
            system_transfer(
                CpiContext::new(
                    ctx.accounts.system_program.to_account_info(),
                    anchor_lang::system_program::Transfer {
                        from: ctx.accounts.bidder.to_account_info(),
                        to: ctx.accounts.vault.to_account_info(),
                    },
                ),
                auction.deposit_amount,
            )?;
            bidder_state.deposit_paid = true;
            auction.deposit_count = auction
                .deposit_count
                .checked_add(1)
                .ok_or(ErrorCode::MathOverflow)?;
        }

        bidder_state.bidder = ctx.accounts.bidder.key();
        bidder_state.auction = auction.key();
        bidder_state.refunded = false;
        bidder_state.bump = ctx.bumps.bidder_state;

        // Update auction high bid.
        auction.highest_bid = bid_amount.min(auction.buy_now_price);
        auction.highest_bidder = ctx.accounts.bidder.key();

        // If buy-now reached, end immediately.
        if bid_amount >= auction.buy_now_price {
            auction.ended = true;
        }

        Ok(())
    }

    /// Anyone can close an auction after its scheduled end time if it hasn't been ended yet.
    pub fn end_auction(ctx: Context<EndAuction>) -> Result<()> {
        let auction = &mut ctx.accounts.auction;
        require!(!auction.ended, ErrorCode::AuctionAlreadyEnded);
        let now = Clock::get()?.unix_timestamp;
        require!(now >= auction.end_time, ErrorCode::AuctionStillRunning);

        auction.ended = true;
        Ok(())
    }

    /// Losers reclaim their deposit (if any) after the auction ends.
    pub fn claim_refund(ctx: Context<ClaimRefund>) -> Result<()> {
        let auction = &mut ctx.accounts.auction;
        require!(auction.ended, ErrorCode::AuctionNotEnded);
        require!(
            auction.highest_bidder != ctx.accounts.bidder.key(),
            ErrorCode::WinnerMustClaimViaWinnerPath
        );

        let bidder_state = &mut ctx.accounts.bidder_state;
        require!(!bidder_state.refunded, ErrorCode::AlreadyRefunded);
        require!(
            auction.deposit_amount == 0 || bidder_state.deposit_paid,
            ErrorCode::DepositNotPaid
        );
        require!(
            bidder_state.bidder == ctx.accounts.bidder.key(),
            ErrorCode::UnauthorizedBidderState
        );
        require!(
            bidder_state.auction == auction.key(),
            ErrorCode::WrongAuction
        );

        transfer_from_vault(
            &ctx.accounts.vault,
            &ctx.accounts.bidder.to_account_info(),
            auction.deposit_amount,
            &ctx.accounts.system_program,
            ctx.bumps.vault,
        )?;
        auction.deposit_count = auction.deposit_count.saturating_sub(1);
        bidder_state.refunded = true;
        Ok(())
    }

    /// Winner settles: collects remaining payment (price - deposit), then pays auctioneer; deposit counts toward price.
    pub fn claim_winner(ctx: Context<ClaimWinner>) -> Result<()> {
        let auction = &mut ctx.accounts.auction;
        require!(auction.ended, ErrorCode::AuctionNotEnded);
        require!(!auction.settled, ErrorCode::AlreadySettled);
        require!(
            auction.highest_bidder == ctx.accounts.winner.key(),
            ErrorCode::NotHighestBidder
        );

        let bidder_state = &mut ctx.accounts.bidder_state;
        require!(!bidder_state.refunded, ErrorCode::AlreadyRefunded);
        require!(
            auction.deposit_amount == 0 || bidder_state.deposit_paid,
            ErrorCode::DepositNotPaid
        );
        require!(
            bidder_state.auction == auction.key(),
            ErrorCode::WrongAuction
        );

        let sale_price = auction.highest_bid;

        // Collect remaining payment from winner (sale price minus deposit already held).
        let deposit_applied = auction.deposit_amount.min(sale_price);
        let remaining = sale_price
            .checked_sub(deposit_applied)
            .ok_or(ErrorCode::MathOverflow)?;
        if remaining > 0 {
            system_transfer(
                CpiContext::new(
                    ctx.accounts.system_program.to_account_info(),
                    anchor_lang::system_program::Transfer {
                        from: ctx.accounts.winner.to_account_info(),
                        to: ctx.accounts.vault.to_account_info(),
                    },
                ),
                remaining,
            )?;
        }

        // Pay auctioneer full sale price (deposit + remaining now in vault).
        transfer_from_vault(
            &ctx.accounts.vault,
            &ctx.accounts.auctioneer.to_account_info(),
            sale_price,
            &ctx.accounts.system_program,
            ctx.bumps.vault,
        )?;

        auction.deposit_count = auction.deposit_count.saturating_sub(1);
        bidder_state.refunded = true;
        auction.settled = true;
        Ok(())
    }

    /// Auctioneer can seize the winner's deposit if payment is not completed by settlement_deadline.
    pub fn seize_deposit(ctx: Context<SeizeDeposit>) -> Result<()> {
        let auction = &mut ctx.accounts.auction;
        require!(auction.ended, ErrorCode::AuctionNotEnded);
        require!(!auction.settled, ErrorCode::AlreadySettled);
        require!(auction.deposit_amount > 0, ErrorCode::NoDepositToSeize);

        let now = Clock::get()?.unix_timestamp;
        require!(
            now >= auction.settlement_deadline,
            ErrorCode::SettlementDeadlineNotReached
        );

        let bidder_state = &mut ctx.accounts.bidder_state;
        require!(
            auction.highest_bidder == bidder_state.bidder,
            ErrorCode::NotHighestBidder
        );
        require!(!bidder_state.refunded, ErrorCode::AlreadyRefunded);
        require!(bidder_state.deposit_paid, ErrorCode::DepositNotPaid);

        transfer_from_vault(
            &ctx.accounts.vault,
            &ctx.accounts.auctioneer.to_account_info(),
            auction.deposit_amount,
            &ctx.accounts.system_program,
            ctx.bumps.vault,
        )?;

        auction.deposit_count = auction.deposit_count.saturating_sub(1);
        bidder_state.refunded = true;
        Ok(())
    }

    /// Closes the auction account once it has ended and all deposits are reclaimed (deposit_count == 0).
    pub fn close_auction(ctx: Context<CloseAuction>) -> Result<()> {
        let auction = &ctx.accounts.auction;
        require!(auction.ended, ErrorCode::AuctionNotEnded);
        require!(auction.deposit_count == 0, ErrorCode::DepositsOutstanding);
        Ok(())
    }
}

// Account definitions
#[account]
#[derive(InitSpace)]
pub struct Auction {
    pub auctioneer: Pubkey,
    pub auction_id: u64,
    #[max_len(32)]
    pub product: String,
    pub buy_now_price: u64,
    pub starting_bid: u64,
    pub increment: u64,
    pub deposit_amount: u64,
    pub settlement_deadline: i64,
    pub deposit_count: u64,
    pub end_time: i64,
    pub highest_bid: u64,
    pub highest_bidder: Pubkey,
    pub ended: bool,
    pub settled: bool,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct BidderState {
    pub auction: Pubkey,
    pub bidder: Pubkey,
    pub deposit_paid: bool,
    pub refunded: bool,
    pub bump: u8,
}

// Accounts contexts

#[derive(Accounts)]
#[instruction(auction_id: u64)]
pub struct CreateAuction<'info> {
    #[account(mut)]
    pub auctioneer: Signer<'info>,
    #[account(
        init,
        payer = auctioneer,
        seeds = [AUCTION_SEED, auctioneer.key().as_ref(), &auction_id.to_le_bytes()],
        bump,
        space = 8 + Auction::INIT_SPACE
    )]
    pub auction: Account<'info, Auction>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct PlaceBid<'info> {
    #[account(mut)]
    pub bidder: Signer<'info>,
    #[account(mut)]
    pub auction: Account<'info, Auction>,
    #[account(mut, seeds = [VAULT_SEED], bump)]
    pub vault: SystemAccount<'info>,
    #[account(
        init_if_needed,
        payer = bidder,
        space = 8 + BidderState::INIT_SPACE,
        seeds = [BIDDER_SEED, auction.key().as_ref(), bidder.key().as_ref()],
        bump
    )]
    pub bidder_state: Account<'info, BidderState>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct EndAuction<'info> {
    pub authority: Signer<'info>,
    #[account(mut)]
    pub auction: Account<'info, Auction>,
}

#[derive(Accounts)]
pub struct ClaimRefund<'info> {
    #[account(mut)]
    pub bidder: Signer<'info>,
    #[account(mut)]
    pub auction: Account<'info, Auction>,
    #[account(
        seeds = [BIDDER_SEED, auction.key().as_ref(), bidder.key().as_ref()],
        bump = bidder_state.bump
    )]
    pub bidder_state: Account<'info, BidderState>,
    #[account(mut, seeds = [VAULT_SEED], bump)]
    pub vault: SystemAccount<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClaimWinner<'info> {
    #[account(mut)]
    pub winner: Signer<'info>,
    #[account(mut)]
    pub auction: Account<'info, Auction>,
    #[account(
        seeds = [BIDDER_SEED, auction.key().as_ref(), winner.key().as_ref()],
        bump = bidder_state.bump,
    )]
    pub bidder_state: Account<'info, BidderState>,
    /// Auctioneer receives the sale price.
    #[account(mut, address = auction.auctioneer)]
    pub auctioneer: SystemAccount<'info>,
    #[account(mut, seeds = [VAULT_SEED], bump)]
    pub vault: SystemAccount<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SeizeDeposit<'info> {
    #[account(mut, address = auction.auctioneer)]
    pub auctioneer: Signer<'info>,
    #[account(
        mut,
        seeds = [AUCTION_SEED, auction.auctioneer.as_ref(), &auction.auction_id.to_le_bytes()],
        bump = auction.bump
    )]
    pub auction: Account<'info, Auction>,
    #[account(
        seeds = [BIDDER_SEED, auction.key().as_ref(), auction.highest_bidder.as_ref()],
        bump = bidder_state.bump
    )]
    pub bidder_state: Account<'info, BidderState>,
    #[account(mut, seeds = [VAULT_SEED], bump)]
    pub vault: SystemAccount<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CloseAuction<'info> {
    #[account(mut, address = auction.auctioneer)]
    pub auctioneer: Signer<'info>,
    #[account(
        mut,
        seeds = [AUCTION_SEED, auction.auctioneer.as_ref(), &auction.auction_id.to_le_bytes()],
        bump = auction.bump,
        close = auctioneer
    )]
    pub auction: Account<'info, Auction>,
}

// Helpers

fn transfer_from_vault<'info>(
    vault: &SystemAccount<'info>,
    recipient: &AccountInfo<'info>,
    amount: u64,
    system_program: &Program<'info, System>,
    bump: u8,
) -> Result<()> {
    let signer_seeds: [&[u8]; 2] = [VAULT_SEED, &[bump]];

    let cpi_program = system_program.to_account_info();
    let cpi_accounts = anchor_lang::system_program::Transfer {
        from: vault.to_account_info(),
        to: recipient.clone(),
    };
    let signer_slice: &[&[u8]] = &signer_seeds;
    let signer_arr = [signer_slice];
    let cpi_ctx = CpiContext::new_with_signer(cpi_program, cpi_accounts, &signer_arr);
    system_transfer(cpi_ctx, amount)?;
    Ok(())
}

// Errors

#[error_code]
pub enum ErrorCode {
    #[msg("Buy-now price must be >= starting bid")]
    InvalidPricing,
    #[msg("Increment must be positive")]
    InvalidIncrement,
    #[msg("Auction end time must be in the future")]
    EndTimeInPast,
    #[msg("Settlement deadline must be after auction end")]
    InvalidSettlementDeadline,
    #[msg("Auction already ended")]
    AuctionAlreadyEnded,
    #[msg("Auction still running")]
    AuctionStillRunning,
    #[msg("Bid must be at least the starting bid")]
    BidTooLow,
    #[msg("Bid increment too small")]
    IncrementTooSmall,
    #[msg("Invalid bid amount")]
    InvalidBidAmount,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Auction has not ended yet")]
    AuctionNotEnded,
    #[msg("Bidder state does not match signer")]
    UnauthorizedBidderState,
    #[msg("Bidder state does not belong to this auction")]
    WrongAuction,
    #[msg("Highest bidder must settle via winner path")]
    WinnerMustClaimViaWinnerPath,
    #[msg("Already refunded")]
    AlreadyRefunded,
    #[msg("Caller is not the highest bidder")]
    NotHighestBidder,
    #[msg("Deposit not paid yet")]
    DepositNotPaid,
    #[msg("Settlement deadline not reached")]
    SettlementDeadlineNotReached,
    #[msg("No deposit to seize")]
    NoDepositToSeize,
    #[msg("Deposits still outstanding")]
    DepositsOutstanding,
    #[msg("Auction already settled")]
    AlreadySettled,
}
